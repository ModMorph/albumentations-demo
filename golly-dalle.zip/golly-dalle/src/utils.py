import cv2
import os
import numpy as np
import json
import argparse
import PIL
import streamlit as st
import struct
from dall_e import unmap_pixels, map_pixels
import torch
import torchvision.transforms as T
import torchvision.transforms.functional as TF

@st.cache
def get_arguments():
    """Return the values of CLI params"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--image_folder", default="images")
    parser.add_argument("--image_width", default=400, type=int)
    args = parser.parse_args()
    return getattr(args, "image_folder"), getattr(args, "image_width")


@st.cache
def get_images_list(path_to_folder: str) -> list:
    """Return the list of images from folder
    Args:
        path_to_folder (str): absolute or relative path to the folder with images
    """
    image_names_list = [
        x for x in os.listdir(path_to_folder) if x[-3:] in ["jpg", "peg", "png"]
    ]
    return image_names_list


@st.cache
def load_image(image_name: str, path_to_folder: str, bgr2rgb: bool = True):
    """Load the image
    Args:
        image_name (str): name of the image
        path_to_folder (str): path to the folder with image
        bgr2rgb (bool): converts BGR image to RGB if True
    """
    path_to_image = os.path.join(path_to_folder, image_name)
    image = cv2.imread(path_to_image)
    if bgr2rgb:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    return image


@st.cache
def load_random_noise_image(image_dim: tuple = (288,288,3), rand_start: int = 0, rand_end: int = 256):
    """Load Single Color Images
    Args:
        image_dim (tuple): dimensions of generated noise image
        rand_start (int): 0 to 254 uint8 start range value
        rand_end (int): 1 to 256 uint8 end range value
    Returns:
        rgb_image (PIL.Image): returns a noise image
    """

    assert(rand_start >= 0)
    assert(rand_end <= 256)
    assert(rand_end > rand_start)
    assert(len(image_dim) == 2 or len(image_dim) == 3)


    rand_arr = np.random.randint(rand_start, rand_end, image_dim, dtype=np.uint8)
    rgb_image = PIL.Image.fromarray(rand_arr)

    return rgb_image

@st.cache
def load_single_color_image(rgb_hex_value: str = '#ffffff', image_dim: tuple = (288,288,3)):
    """Load Single Color Images
    Args:
        rgb_hex_value (str): 6-character hexadecimal RGB representation
        image_dim (tuple): image dimensions to generate
    Returns:
        rgb_image (PIL.Image): returns solid color RGB PIL image
    """

    assert(len(rgb_hex_value) == 7 or len(rgb_hex_value) == 6)

    r_color = struct.unpack('BBB', bytes.fromhex(rgb_hex_value.replace('#','')))

    mask = np.ones(image_dim, dtype=np.uint8)
    mask[:, :, 0] *= r_color[0]
    mask[:, :, 1] *= r_color[1]
    mask[:, :, 2] *= r_color[2]
    rgb_image = PIL.Image.fromarray(mask)


    return rgb_image



def upload_image(bgr2rgb: bool = True):
    """Upload the image
    Args:
        bgr2rgb (bool): converts BGR image to RGB if True
    """
    file = st.sidebar.file_uploader(
        "Upload your image (jpg, jpeg, or png)", ["jpg", "jpeg", "png"]
    )
    image = cv2.imdecode(np.fromstring(file.read(), np.uint8), 1)
    if bgr2rgb:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    return image


@st.cache
def load_augmentations_config(
    placeholder_params: dict, path_to_config: str = "configs/augmentations.json"
) -> dict:
    """Load the json config with params of all transforms
    Args:
        placeholder_params (dict): dict with values of placeholders
        path_to_config (str): path to the json config file
    """
    with open(path_to_config, "r") as config_file:
        augmentations = json.load(config_file)
    for name, params in augmentations.items():
        params = [fill_placeholders(param, placeholder_params) for param in params]
    return augmentations


@st.cache
def load_textqueries_config(
    placeholder_params: dict, path_to_config: str = "configs/textqueries.json"
) -> dict:
    """Load the json config with params of all transforms
    Args:
        placeholder_params (dict): dict with values of placeholders
        path_to_config (str): path to the json config file
    """
    with open(path_to_config, "r") as config_file:
        tqueries = json.load(config_file)
    for name, params in tqueries.items():
        params = [fill_placeholders(param, placeholder_params) for param in params]
    return tqueries


def fill_placeholders(params: dict, placeholder_params: dict) -> dict:
    """Fill the placeholder values in the config file
    Args:
        params (dict): original params dict with placeholders
        placeholder_params (dict): dict with values of placeholders
    """
    # TODO: refactor
    if "placeholder" in params:
        placeholder_dict = params["placeholder"]
        for k, v in placeholder_dict.items():
            if isinstance(v, list):
                params[k] = []
                for element in v:
                    if element in placeholder_params:
                        params[k].append(placeholder_params[element])
                    else:
                        params[k].append(element)
            else:
                if v in placeholder_params:
                    params[k] = placeholder_params[v]
                else:
                    params[k] = v
        params.pop("placeholder")
    return params


def get_params_string(param_values: dict) -> str:
    """Generate the string from the dict with parameters
    Args:
        param_values (dict): dict of "param_name" -> "param_value"
    """
    params_string = ", ".join(
        [k + "=" + str(param_values[k]) for k in param_values.keys()]
    )
    return params_string


def get_placeholder_params(image):
    return {
        "image_width": image.shape[1],
        "image_height": image.shape[0],
        "image_half_width": int(image.shape[1] / 2),
        "image_half_height": int(image.shape[0] / 2),
    }

def get_dalle_onehot(selected_idx: int = 0):
    z = np.zeros((1, 8192, 32, 32), dtype=np.float32)
    z[:, selected_idx, :, :] = 1

    z = torch.from_numpy(z)
    return z


def select_transformations(augmentations: dict, interface_type: str) -> list:
    # in the Simple mode you can choose only one transform
    # if interface_type == "Simple":
    #     transform_names = [
    #         st.sidebar.selectbox(
    #             "Select a transformation:", sorted(list(augmentations.keys()))
    #         )
    #     ]
    # # in the professional mode you can choose several transforms
    # elif interface_type == "Professional":




    transform_names = [
        st.sidebar.selectbox(
                "Select transformation №1:", sorted(list(augmentations.keys()))
            )
    ]

    #
    #TODO: fix key error/infinite loop.
    #
    # while transform_names[-1] != "None":
    #
    #
    #     skey = f'transform_{len(transform_names) + 1}'
    #
    #
    #     last_select = st.sidebar.selectbox(
    #         f"Select transformation №{len(transform_names) + 1}:",
    #         ["None"] + sorted(list(augmentations.keys())),
    #         key=skey
    #     )
    #     transform_names.append(last_select)
    #
    #     if last_select =="None":
    #         break
    #
    #     transform_names = transform_names[:-1]
    return transform_names


def dalle_preprocess(np_img, target_image_size: int = 256):

    if type(np_img) is np.ndarray:
        print('converting from numpy array')
        img=PIL.Image.fromarray(np_img)
    else:
        img = np_img

    s = min(img.size)

    if s < target_image_size:
        raise ValueError(f'min dim for image {s} < {target_image_size}')

    r = target_image_size / s
    s = (round(r * img.size[1]), round(r * img.size[0]))
    img = TF.resize(img, s, interpolation=PIL.Image.LANCZOS)
    img = TF.center_crop(img, output_size=2 * [target_image_size])
    img = torch.unsqueeze(T.ToTensor()(img), 0)
    return map_pixels(img)


def dalle_postprocess(x_stats):
    x_image = unmap_pixels(x_stats[:, :3])
    x_constrastive = unmap_pixels(x_stats[:, 3:])
    x_image = T.ToPILImage(mode='RGB')(x_image[0])
    x_constrastive = T.ToPILImage(mode='RGB')(x_constrastive[0])

    return x_image, x_constrastive




def show_random_params(data: dict, interface_type: str = "CLIP",container=None):
    """Shows random params used for transformation (from A.ReplayCompose)"""
    if interface_type == "CLIP":

        if container is not None:
            container.subheader("Random params used")
            random_values = {}
            for applied_params in data["replay"]["transforms"]:
                random_values[
                    applied_params["__class_fullname__"].split(".")[-1]
                ] = applied_params["params"]
            container.write(random_values)
        else:

            st.subheader("Random params used")
            random_values = {}
            for applied_params in data["replay"]["transforms"]:
                random_values[
                    applied_params["__class_fullname__"].split(".")[-1]
                ] = applied_params["params"]
            st.write(random_values)
