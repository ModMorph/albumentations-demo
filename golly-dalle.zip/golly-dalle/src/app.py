import os
import streamlit as st
import albumentations as A

import dall_e as dalle

import clip as clip


from interface import (
    get_device_options,

    Backend


)


from utils import (
    load_augmentations_config,
    load_textqueries_config,
    get_arguments,
    get_placeholder_params,
    select_transformations,
    show_random_params,
    load_single_color_image,
    load_random_noise_image,
    dalle_preprocess,
    dalle_postprocess,
    get_dalle_onehot
)
from visuals import (
    select_image,
    show_credentials,
    show_docstring,
    get_transormations_params,
    show_encoding_ui
)


def main():
    dalle_modification_change = None
    cmp_image = None
    cmp_image2 = None
    image_width=600

    backend = Backend()


    def get_image_token_mapping_panel(selected_image,encode_it,container_1,container_2):

        if encode_it:


            dallefied_image = dalle_preprocess(selected_image)
            z, _, tokenmap = backend.encode_dalle_image(dallefied_image)
            print(z.shape)

            decoded = backend.decode_dalle_z(z)

            z = z.clone().cpu().numpy()

            decoded_image_1A, decoded_image_1B = dalle_postprocess(decoded)



            show_encoding_ui(tokenmap, decoded_image_1A, decoded_image_1B,
                                                                           container_1,container_2)


            # if dalle_modification_change > -1:
            #     z[0, :, h_range, w_range] = 0
            #     z[0, dalle_modification_change, h_range, w_range] = 1
            #     decoded = backend.decode_dalle_z(z)
            #
            #     z = z.clone().cpu().numpy()
            #
            #     decoded_image_1A, decoded_image_1B = dalle_postprocess(decoded)



    # get CLI params: the path to images and image width
    path_to_images, width_original = get_arguments()

    if not os.path.isdir(path_to_images):
        st.title("There is no directory: " + path_to_images)
    else:

        col_header,col_header_2 = st.beta_columns([7,1])

        col1, col2, col3, col4 = st.beta_columns([2, 2, 2, 2])
        col1b, col2b = st.beta_columns([2, 3])


        # select interface type
        interface_type = st.sidebar.radio(
            "Test", ["Dall-E", "CLIP"]
        )

        dev_count = get_device_options()

        if dev_count > 0:

            if "GA" in os.environ:
                selected_device_type ="cuda:0"
            else:
                #allow to select locally
                selected_device_type = st.sidebar.radio(
                "cuda:0",["cpu","cuda:0"]
                )
        else:
            selected_device_type ="cpu"

        #
        # Select a Specific CLIP model to Query
        #
        if interface_type == "CLIP":
            available_clip_models = clip.available_models()
            available_clip_models.insert(0, None)
            selected_clip_model = st.sidebar.selectbox('CLIP model', (available_clip_models))

            if selected_clip_model:
                with st.spinner(f'Loading your selected CLIP Model: {selected_clip_model}. (May take a while to download 1st time)'):
                    backend.load_clip_model(selected_clip_model, selected_device_type)

            text_prefix_input = st.sidebar.text_input('Enter any prefix added to all text prompts')

            text_input_box = st.sidebar.text_area('Enter a text prompt, separated by semi-colon')

            text_suffix_input = st.sidebar.text_input('Enter any suffix added to all text prompts')

        else:

            with st.spinner(f'Loading the DALL-E Model. (May take a while to download 1st time)'):
                backend.load_dalle_model(selected_device_type)



        selected_color = st.sidebar.color_picker('Select a Color to Compare')

        if selected_color:
            cmp_image = load_single_color_image(selected_color)
            pass

        selected_noise_image_button = st.sidebar.button('Generate Noise Image')

        if selected_noise_image_button:
            cmp_image = load_random_noise_image()
            pass


        selected_dalle_image_button = st.sidebar.number_input('Enter a Dall-E Token',0,8191)

        if selected_dalle_image_button:
            z=get_dalle_onehot(selected_dalle_image_button)
            decoded = backend.decode_dalle_z(z)
            cmp_image, cmp_image2 = dalle_postprocess(decoded)

        # select image
        status, image = select_image(path_to_images, interface_type)
        if status == 1:
            st.title("Can't load image")
        if status == 2:
            st.title("Upload image")
        else:
            # image was loaded successfully
            placeholder_params = get_placeholder_params(image)

            # load the config
            augmentations = load_augmentations_config(
                placeholder_params, "configs/augmentations.json"
            )

            # load the config
            textqueries = load_textqueries_config(
                placeholder_params, "configs/textqueries.json"
            )


            # get the list of transformations names
            transform_names = select_transformations(augmentations, interface_type)

            # get parameters for each transform
            transforms = get_transormations_params(transform_names, augmentations)

            try:
                # apply the transformation to the image
                data = A.ReplayCompose(transforms)(image=image)
                error = 0
            except ValueError:
                error = 1
                st.title(
                    "An error has occurred. Most probably you have passed wrong set of parameters. \
                Check transforms that change the shape of image."
                )

            # proceed only if everything is ok
            if error == 0:
                augmented_image = data["image"]
                # show title

                if interface_type == 'CLIP':
                    if selected_clip_model is None:
                        col_header.title(f"🙌 4 Clip: Select a Model")
                    else:
                        col_header.title(f"🙌 4 Clip: {selected_clip_model} Model")
                else:
                    col_header.title("Golly 🤖 Dall-E!")

                # show the images
                width_transformed = int(
                    width_original / image.shape[1] * augmented_image.shape[1]
                )




                #
                #  Column 1
                #

                col1.image(image, caption="Original image", width=image_width)


                if image is not None and interface_type == "Dall-E":
                    encode_image = col1.button('Encode Image')

                    get_image_token_mapping_panel(image, encode_image, col1b, col2b)




                #
                # Column 2
                #



                col2.image(
                    augmented_image,
                    caption="Transformed image",
                    width=image_width,
                 use_column_width = False
                )

                if augmented_image is not None and interface_type == "Dall-E":
                    encode_image = col2.button('Encode Image',key='denc_button2')
                    get_image_token_mapping_panel(augmented_image,encode_image, col1b, col2b)




                #
                # Column 3
                #
                col3.image(cmp_image,caption="Comparison Image",width=image_width)

                if cmp_image is not None and interface_type == "Dall-E":
                    encode_cmp_image= col3.button('Encode Image',key='denc_button3')

                    if encode_cmp_image:
                        get_image_token_mapping_panel(cmp_image, encode_cmp_image, col1b, col2b)


                if cmp_image2 is not None:
                    col4.image(cmp_image2, caption="Comparison Image #2", width=image_width)

                    if interface_type == "Dall-E":
                        encode_cmp_image2 = col3.button('Encode Image', key='denc_button4')

                        get_image_token_mapping_panel(cmp_image2, encode_cmp_image2, col1b, col2b)

                # comment about refreshing
                #st.write("*Press 'R' to refresh*")


                albumentation_info_expander = st.sidebar.beta_expander("Albumentations Transform Info", expanded=False)


                if albumentation_info_expander:
                    # random values used to get transformations
                    show_random_params(data, interface_type,albumentation_info_expander)

                    # print additional info
                    for transform in transforms:
                        show_docstring(transform,albumentation_info_expander)
                        albumentation_info_expander.code(str(transform))
                    show_credentials(albumentation_info_expander)

                # adding google analytics pixel
                # only when deployed online. don't collect statistics of local usage
                if "GA" in os.environ:
                    st.image(os.environ["GA"])
                    st.markdown(
                        (
                            "[Privacy policy]"
                            + (
                                "(https://htmlpreview.github.io/?"
                                + "https://github.com/ModMorph/"
                                + "golly-dalle/blob/deploy/docs/privacy.html)"
                            )
                        )
                    )


if __name__ == "__main__":
    main()
