import clip
from clip.simple_tokenizer import SimpleTokenizer
from dall_e import load_model
import streamlit as st
import os
import torch
import torch.nn.functional as F

import numpy as np

@st.cache
def get_device_options():

    available_gpus = 0

    if torch.cuda.is_available():

        available_gpus=torch.cuda.device_count()


    return available_gpus




def _load_clip_model(clip_model_selection,device, jit=True ):

    model, preprocess = clip.load(clip_model_selection, jit=jit, device=device)

    if device == 'cpu':
        model.eval()
    else:
        model.cuda().eval()

    return model, preprocess


def _load_dalle_vae_model(device):



        if not os.path.exists('checkpoints/encoder.pkl'):
            enc = load_model("https://cdn.openai.com/dall-e/encoder.pkl", device)
        else:
            enc = load_model('checkpoints/encoder.pkl')

        if not os.path.exists("checkpoints/decoder.pkl"):
            dec = load_model("https://cdn.openai.com/dall-e/decoder.pkl", device)
        else:
            dec = load_model("checkpoints/decoder.pkl", device)

            return enc,dec




class Backend(object):

    def __init__(self, jit=True):

        super().__init__()

        self.clip_model = {}
        self.clip_processing = {}
        self.dalle_enc = None
        self.dalle_dec = None
        self.jit = jit
        pass

    def load_clip_model(self, selected_clip_model: str, selected_device_type:str):

        if selected_clip_model not in self.clip_model:

            if selected_clip_model is not None and selected_clip_model != 'None':
                model, preprocessing = _load_clip_model(selected_clip_model,selected_device_type, jit=self.jit)

                self.clip_model[selected_clip_model]=model
                self.clip_processing[selected_clip_model]=preprocessing


    def load_dalle_model(self, selected_device_type: str):
        enc,dec = _load_dalle_vae_model(selected_device_type)

        self.dalle_enc = enc
        self.dalle_dec = dec


    def encode_dalle_image(self,x):

        z_logits = self.dalle_enc(x)
        z = torch.argmax(z_logits, axis=1)
        z = F.one_hot(z, num_classes=self.dalle_enc.vocab_size).permute(0, 3, 1, 2).float()

        z_np = torch.argmax(z,axis=1)[0]

        z_np = z_np.numpy()

        return z, z_logits,z_np

    def decode_dalle_z(self, z):



        x_stats = self.dalle_dec(z).float()
        with torch.no_grad():
            return torch.sigmoid(x_stats)



    def encode_clipimage(self,images):

        with torch.no_grad():
            image_mean = torch.tensor([0.48145466, 0.4578275, 0.40821073]).cuda()
            image_std = torch.tensor([0.26862954, 0.26130258, 0.27577711]).cuda()

            image_input = torch.tensor(np.stack(images)).cuda()
            image_input -= image_mean[:, None, None]
            image_input /= image_std[:, None, None]

            image_features = self.clip_model.encode_image(image_input).float()

            image_features = image_features.cpu().numpy()

            #TODO: Normstep?
            image_features /= image_features.norm(dim=-1, keepdim=True)

            return image_features

    def encode_cliplangtokens(self,langtokens):

        with torch.no_grad():
            langtokens = langtokens.cuda()


            text_features = self.clip_model.encode_text(langtokens).float()

            # TODO: Normstep?
            text_features /= text_features.norm(dim=-1, keepdim=True)

            text_features = text_features.cpu().numpy()

            return text_features


    def get_tokens(self,prefix,text,suffix):

        tokenizer = SimpleTokenizer()

        text_tokens = [tokenizer.encode(prefix + desc.strip() + suffix) for desc in
                       text_input_box.split(';')]
        text_strings = [prefix.lower() + desc.strip().lower() + suffix.lower() for desc in
                        text.split(';')]

        text_input = torch.zeros(len(text_tokens), self.clip_model.context_length, dtype=torch.long)
        sot_token = tokenizer.encoder['<|startoftext|>']
        eot_token = tokenizer.encoder['<|endoftext|>']

        for i, tokens in enumerate(text_tokens):
            tokens = [sot_token] + tokens + [eot_token]
            text_input[i, :len(tokens)] = torch.tensor(tokens)



        return text_input, text_strings, text_tokens