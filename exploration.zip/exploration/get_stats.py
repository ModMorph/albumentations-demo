import numpy as np
import torch
import clip
from tqdm.notebook import tqdm
import pandas as pd

print("Torch version:", torch.__version__)
model, preprocess = clip.load('RN50x4')  #ViT-B/32'


counter = 0
model_name = []
layer_number = []
model_part = []
layer_name = []
layer_sum = []
layer_dtype = []
layer_mean = []
layer_median = []
layer_std = []
layer_prod = []
layer_var = []
layer_nonzero = []
layer_num_elements = []
layer_max = []
layer_min = []
layer_shape = []
layer_requires_grad = []
layer_dim = []
later_element_size = []

level_counter_list = []
level_counter2_list = []
expo_list = []

for name, param in model.visual.named_parameters():
    with torch.no_grad():
        layer_number.append(counter)
        # print(name,param.dtype,torch.sum(param).cpu().numpy(),torch.mean(param).cpu().numpy(),torch.median(param).cpu().numpy(),
        #      torch.std(param).cpu().numpy(),torch.prod(param).cpu().numpy(),
        #     torch.var(param).cpu().numpy(),torch.count_nonzero(param).cpu().numpy(),
        #      torch.max(param).cpu().numpy(),
        #      torch.min(param).cpu().numpy(),param.shape,param.requires_grad,param.data.dim(),
        #     torch.numel(param.data))

        model_name.append('ViT-B/32')
        model_part.append('visual')
        layer_name.append(name)

        layer_sum.append(torch.sum(param).cpu().numpy())
        layer_dtype.append(param.dtype)
        layer_mean.append(torch.mean(param).cpu().numpy())
        layer_median.append(torch.median(param).cpu().numpy())
        layer_std.append(torch.std(param).cpu().numpy())
        layer_prod.append(torch.prod(param).cpu().numpy())
        layer_var.append(torch.var(param).cpu().numpy())
        layer_nonzero.append(torch.count_nonzero(param).cpu().numpy())
        layer_num_elements.append(torch.numel(param.data))
        layer_max.append(torch.max(param).cpu().numpy())
        layer_min.append(torch.min(param).cpu().numpy())
        layer_shape.append(param.shape)
        layer_requires_grad.append(param.requires_grad)
        layer_dim.append(param.data.dim())

        level_counter = {'model': 'ViT-B/32', 'part': 'visual', 'layer': name, 'i': counter, '0': 0, '1': 0, '2': 0,
                         '3': 0, '4': 0, '5': 0, '6': 0, '7': 0,
                         '8': 0, '9': 0, '-0': 0, '-1': 0, '-2': 0, '-3': 0, '-4': 0, '-5': 0, '-6': 0, '-7': 0,
                         '-8': 0, '-9': 0}
        level_counter2 = {'model': 'ViT-B/32', 'part': 'visual', 'layer': name, 'i': counter, '0': 0, '1': 0, '2': 0,
                          '3': 0, '4': 0, '5': 0, '6': 0, '7': 0,
                          '6': 0, '8': 0, '9': 0}

        lvl_exponent = {'model': 'ViT-B/32', 'part': 'visual', 'layer': name, 'i': counter, '00': 0, '+01': 0, '+02': 0,
                        '+03': 0, '+04': 0, '+05': 0, '+06': 0, '+07': 0,
                        '+08': 0, '+09': 0, '+00': 0, '-00': 0, '-01': 0, '-02': 0, '-03': 0, '-04': 0, '-05': 0,
                        '-06': 0, '-07': 0,
                        '-08': 0, '-09': 0, '-10': 0, '-11': 0, '-12': 0, '-13': 0, '-14': 0, '-15': 0, '-16': 0,
                        '-17': 0, '-18': 0, '-19': 0, '-20': 0, '-21': 0, '-22': 0, '-23': 0, '-24': 0}

        np_param = param.cpu().detach().numpy().flatten()
        # print(f'len(np_param)={len(np_param)}')

        reps = len(np_param) // 10000

        if len(np_param) % 10000 != 0:
            reps += 1

        for j in range(reps):
            start = j * 10000
            end = start + 10000
            if j == reps - 1:
                section = np_param[start:]
                # print(f'len(section)={len(section)} reps={reps} j={j} npparamlen={len(np_param)}')
            else:
                section = np_param[start:end]

            digits = np.array2string(section, formatter={'float_kind': lambda x: ("%0.1E" % x).split('E')[0]},
                                     threshold=1000000000)

            exponent = np.array2string(section, formatter={'float_kind': lambda x: ("%0.1E" % x).split('E')[1]},
                                       threshold=1000000000)

            if len(digits) > 0:
                for d in digits.split(" "):
                    digit = d.replace("\n", "").replace('[', '').replace(']', '')
                    fdigit = digit.split(".")[0]
                    sdigit = digit.split(".")[1]
                    level_counter[fdigit] += 1
                    level_counter2[sdigit] += 1

            if len(exponent) > 0:
                for d in exponent.split(" "):
                    digit = d.replace("\n", "").replace('[', '').replace(']', '')
                    # print(digit)
                    lvl_exponent[digit] += 1

        level_counter_list.append(level_counter)
        level_counter2_list.append(level_counter2)
        expo_list.append(lvl_exponent)

        counter += 1

counter

counter = 0

for name, param in model.token_embedding.named_parameters():
    with torch.no_grad():
        layer_number.append(counter)
        # print(name,param.dtype,torch.sum(param).cpu().numpy(),torch.mean(param).cpu().numpy(),torch.median(param).cpu().numpy(),
        #   torch.std(param).cpu().numpy(),torch.prod(param).cpu().numpy(),
        # torch.var(param).cpu().numpy(),torch.count_nonzero(param).cpu().numpy(),
        #   torch.max(param).cpu().numpy(),
        #   torch.min(param).cpu().numpy(),param.shape,param.requires_grad,param.data.dim(),
        #   torch.numel(param.data))

        model_name.append('ViT-B/32')
        model_part.append('token_embedding')
        layer_name.append(name)

        layer_sum.append(torch.sum(param).cpu().numpy())
        layer_dtype.append(param.dtype)
        layer_mean.append(torch.mean(param).cpu().numpy())
        layer_median.append(torch.median(param).cpu().numpy())
        layer_std.append(torch.std(param).cpu().numpy())
        layer_prod.append(torch.prod(param).cpu().numpy())
        layer_var.append(torch.var(param).cpu().numpy())
        layer_nonzero.append(torch.count_nonzero(param).cpu().numpy())
        layer_num_elements.append(torch.numel(param.data))
        layer_max.append(torch.max(param).cpu().numpy())
        layer_min.append(torch.min(param).cpu().numpy())
        layer_shape.append(param.shape)
        layer_requires_grad.append(param.requires_grad)
        layer_dim.append(param.data.dim())

        level_counter = {'model': 'ViT-B/32', 'part': 'token_embedding', 'layer': name, 'i': counter, '0': 0, '1': 0,
                         '2': 0, '3': 0, '4': 0, '5': 0, '6': 0, '7': 0,
                         '8': 0, '9': 0, '-0': 0, '-1': 0, '-2': 0, '-3': 0, '-4': 0, '-5': 0, '-6': 0, '-7': 0,
                         '-8': 0, '-9': 0}
        level_counter2 = {'model': 'ViT-B/32', 'part': 'token_embedding', 'layer': name, 'i': counter, '0': 0, '1': 0,
                          '2': 0, '3': 0, '4': 0, '5': 0, '6': 0, '7': 0,
                          '6': 0, '8': 0, '9': 0}

        lvl_exponent = {'model': 'ViT-B/32', 'part': 'token_embedding', 'layer': name, 'i': counter, '00': 0, '+01': 0,
                        '+02': 0, '+03': 0, '+04': 0, '+05': 0, '+06': 0, '+07': 0,
                        '+08': 0, '+09': 0, '+00': 0, '-00': 0, '-01': 0, '-02': 0, '-03': 0, '-04': 0, '-05': 0,
                        '-06': 0, '-07': 0,
                        '-08': 0, '-09': 0, '-10': 0, '-11': 0, '-12': 0, '-13': 0, '-14': 0, '-15': 0, '-16': 0,
                        '-17': 0, '-18': 0, '-19': 0, '-20': 0, '-21': 0, '-22': 0, '-23': 0, '-24': 0}

        np_param = param.cpu().detach().numpy().flatten()
        # print(f'len(np_param)={len(np_param)}')

        reps = len(np_param) // 10000

        if len(np_param) % 10000 != 0:
            reps += 1

        for j in range(reps):
            start = j * 10000
            end = start + 10000
            if j == reps - 1:
                section = np_param[start:]
                # print(f'len(section)={len(section)} reps={reps} j={j} npparamlen={len(np_param)}')
            else:
                section = np_param[start:end]

            digits = np.array2string(section, formatter={'float_kind': lambda x: ("%0.1E" % x).split('E')[0]},
                                     threshold=1000000000)

            exponent = np.array2string(section, formatter={'float_kind': lambda x: ("%0.1E" % x).split('E')[1]},
                                       threshold=1000000000)

            if len(digits) > 0:
                for d in digits.split(" "):
                    digit = d.replace("\n", "").replace('[', '').replace(']', '')
                    fdigit = digit.split(".")[0]
                    sdigit = digit.split(".")[1]
                    level_counter[fdigit] += 1
                    level_counter2[sdigit] += 1

            if len(exponent) > 0:
                for d in exponent.split(" "):
                    digit = d.replace("\n", "").replace('[', '').replace(']', '')

                    lvl_exponent[digit] += 1

        level_counter_list.append(level_counter)
        level_counter2_list.append(level_counter2)
        expo_list.append(lvl_exponent)
        counter += 1

counter

counter = 0

for name, param in model.ln_final.named_parameters():
    with torch.no_grad():
        layer_number.append(counter)
        # print(name,param.dtype,torch.sum(param).cpu().numpy(),torch.mean(param).cpu().numpy(),torch.median(param).cpu().numpy(),
        #  torch.std(param).cpu().numpy(),torch.prod(param).cpu().numpy(),
        #   torch.var(param).cpu().numpy(),torch.count_nonzero(param).cpu().numpy(),
        #    torch.max(param).cpu().numpy(),
        #     torch.min(param).cpu().numpy(),param.shape,param.requires_grad,param.data.dim(),
        #     torch.numel(param.data))

        model_name.append('ViT-B/32')
        model_part.append('ln_final')
        layer_name.append(name)

        layer_sum.append(torch.sum(param).cpu().numpy())
        layer_dtype.append(param.dtype)
        layer_mean.append(torch.mean(param).cpu().numpy())
        layer_median.append(torch.median(param).cpu().numpy())
        layer_std.append(torch.std(param).cpu().numpy())
        layer_prod.append(torch.prod(param).cpu().numpy())
        layer_var.append(torch.var(param).cpu().numpy())
        layer_nonzero.append(torch.count_nonzero(param).cpu().numpy())
        layer_num_elements.append(torch.numel(param.data))
        layer_max.append(torch.max(param).cpu().numpy())
        layer_min.append(torch.min(param).cpu().numpy())
        layer_shape.append(param.shape)
        layer_requires_grad.append(param.requires_grad)
        layer_dim.append(param.data.dim())

        level_counter = {'model': 'ViT-B/32', 'part': 'ln_final', 'layer': name, 'i': counter, '0': 0, '1': 0, '2': 0,
                         '3': 0, '4': 0, '5': 0, '6': 0, '7': 0,
                         '8': 0, '9': 0, '-0': 0, '-1': 0, '-2': 0, '-3': 0, '-4': 0, '-5': 0, '-6': 0, '-7': 0,
                         '-8': 0, '-9': 0}
        level_counter2 = {'model': 'ViT-B/32', 'part': 'ln_final', 'layer': name, 'i': counter, '0': 0, '1': 0, '2': 0,
                          '3': 0, '4': 0, '5': 0, '6': 0, '7': 0,
                          '6': 0, '8': 0, '9': 0}

        lvl_exponent = {'model': 'ViT-B/32', 'part': 'ln_final', 'layer': name, 'i': counter, '00': 0, '+01': 0,
                        '+02': 0, '+03': 0, '+04': 0, '+05': 0, '+06': 0, '+07': 0,
                        '+08': 0, '+09': 0, '+00': 0, '-00': 0, '-01': 0, '-02': 0, '-03': 0, '-04': 0, '-05': 0,
                        '-06': 0, '-07': 0,
                        '-08': 0, '-09': 0, '-10': 0, '-11': 0, '-12': 0, '-13': 0, '-14': 0, '-15': 0, '-16': 0,
                        '-17': 0, '-18': 0, '-19': 0, '-20': 0, '-21': 0, '-22': 0, '-23': 0, '-24': 0}

        np_param = param.cpu().detach().numpy().flatten()
        # print(f'len(np_param)={len(np_param)}')

        reps = len(np_param) // 10000

        if len(np_param) % 10000 != 0:
            reps += 1

        for j in range(reps):
            start = j * 10000
            end = start + 10000
            if j == reps - 1:
                section = np_param[start:]
                # print(f'len(section)={len(section)} reps={reps} j={j} npparamlen={len(np_param)}')
            else:
                section = np_param[start:end]

            digits = np.array2string(section, formatter={'float_kind': lambda x: ("%0.1E" % x).split('E')[0]},
                                     threshold=1000000000)

            exponent = np.array2string(section, formatter={'float_kind': lambda x: ("%0.1E" % x).split('E')[1]},
                                       threshold=1000000000)

            if len(digits) > 0:
                for d in digits.split(" "):
                    digit = d.replace("\n", "").replace('[', '').replace(']', '')
                    fdigit = digit.split(".")[0]
                    sdigit = digit.split(".")[1]
                    level_counter[fdigit] += 1
                    level_counter2[sdigit] += 1

            if len(exponent) > 0:
                for d in exponent.split(" "):
                    digit = d.replace("\n", "").replace('[', '').replace(']', '')

                    lvl_exponent[digit] += 1

        level_counter_list.append(level_counter)
        level_counter2_list.append(level_counter2)
        expo_list.append(lvl_exponent)
        counter += 1

counter

counter = 0

# df = pd.DataFrame({'model_name': model_name,
#                    'layer_number': layer_number,
#                    'model_part': model_part,
#
#                    'layer_name': layer_name,
#                    'layer_dtype': layer_dtype,
#                    'layer_nonzero': layer_nonzero,
#                    'layer_num_elements': layer_num_elements,
#                    'layer_sum': layer_sum,
#                    'layer_mean': layer_mean,
#                    'layer_std': layer_std,
#                    'layer_median': layer_median,
#                    'layer_prod': layer_prod,
#                    'layer_var': layer_var,
#                    'layer_max': layer_max,
#                    'layer_min': layer_min,
#                    'layer_shape': layer_shape,
#                    'layer_requires_grad': layer_requires_grad,
#                    'layer_dim': layer_dim,
#                    }
#
#                   )
#
# df.to_csv('modinforn50x4.csv')

df = pd.DataFrame(level_counter_list)
df.to_csv(f'lvl_counter_RN50X4.csv')

df = pd.DataFrame(level_counter2_list)
df.to_csv(f'lvl_counter2_RN50X4.csv')

df = pd.DataFrame(expo_list)
df.to_csv(f'expo_RN50X4.csv')
