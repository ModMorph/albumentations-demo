
import subprocess
import numpy as np




def generate_center_square():


    pass


def get_combinations():
    #black, white, grey, yellow, chromakey green , red, blue,cyan  - random reddish color
    colors = ['000000','ffffff','888888','ffff00','00ff00','ff0000','0000ff','00ffff','921e3e']

    square_type = ['solid','1px','5px']
    square_range = [np.arange(0,224),np.arange(0,224),np.arange(0,224)]








emojis = ['⬛','⬜','◼','◻','◾','◽','▪','▫']

#Flags with tricolors, bicolors unicolors or related patterns with quickly calculable surface area ratios for colors.

#Brown, Purple, Blue, Green, Yellow, Orange, Red Squares, White Square Button, Black Square Button, Checkered Flag,Black Flag, White Flag, Red Flag, Rainbow Flag, French Flag, Guinea Flag, Hungary Flag, Irish Flag, Italian Flag, Luxembourg Flag, Monaco, Saint Martin,Mauritius,Netherlands, Peru, Panama, POland, Romania, Russia, Sierra Leone,Thailand,Ukraine,Yemen, flag: Vietnam, Mali, Lithuania, Greenland, Gabon, Estonia, Germany, Clipperton Island, Colombia, Côte d’Ivoire, Congo - Brazzaville,Benin, Bulgaria,Belgium, Austria, Armenia, Large Blue Diamond, Small Blue Diamond, Hollow Red Circle,Stop Button, Drop of Blood, Bar Chart, Diamond Suit, Star, Stop Sign, Red Apple, Record Button, Black Circle, White Circle, Orange Circle
emojis_2 = ['🟫','🟪','🟦','🟩','🟨','🟧','🟥','🔳','🔲','🏁','🏴','🏳','🚩','🏳️‍🌈','🇫🇷','🇬🇳','🇭🇺','🇮🇩','🇮🇪','🇮🇹','🇱🇺','🇲🇨','🇲🇫','🇲🇺','🇳🇬','🇳🇱','🇵🇪','🇵🇦','🇵🇱','🇷🇴','🇷🇺','🇸🇱','🇹🇭','🇺🇦','🇾🇪','🇻🇳','🇲🇱','🇱🇹','🇬🇱','🇬🇦', '🇪🇪','🇩🇪','🇨🇵','🇨🇴','🇨🇮','🇨🇬','🇧🇯','🇧🇬','🇧🇪','🇦🇹','🇦🇲','🔷','🔹','⭕','⏹','🩸','📊','♦','⭐','🛑','🍎','⏺','⚫','⚪','🟠']


emoji_descriptions=['Black Large Square','White Large Square','Black Medium Square','White Medium Square','Black Medium-Small Square','White Medium-Small Square','Black Small Square','White Small Square']


variations = ['Black Square','White Square','Grey Square','Tiny Square','Small Square','Medium-Small Square','Medium Square','Large Square','Big Square','Green Square','Red Square','Blue Square',
              'Yellow Square','White','Black','Grey','Red','Green','Yellow','Blue','Rectangle','Quadrilateral','Tiny','Small','Medium','Medium-Small',
              'Large','Big','Giant','Line','Polygon','Circle','Triangle','Center','Left','Right','Top','Bottom']


emptyset = ['']

cmp_prompts = []

cmp_prompts.extend(emojis)
cmp_prompts.extend(emoji_descriptions)
cmp_prompts.extend(variations)


#'exp_a1/colors'
src_dirs = ['exp_a1/colors','exp_a1/200_sq','exp_a1/148_sq','exp_a1/112_sq','exp_a1/56_sq','exp_a1/12_sq','exp_a1/4_sq']


for model in ["ViT-B/32","RN101"]:

    print(f'model = {model}')

    for src_dir in src_dirs:

        print(f"src_dir = {src_dir}")


        # print('emojis')
        # for i in range(len(emojis)):
        #     prompt = emojis[i]
        #     print(f'prompt:{prompt}')
        #
        #     subprocess.call(['python','rank_lister.py','-prompt',prompt,'-model',model,'-src_dir',src_dir])

        print('emptyset')
        for i in range(len(emptyset)):
            prompt = emptyset[i]
            print(f'prompt:{prompt}')

            subprocess.call(['python', 'rank_lister.py', '-prompt', prompt, '-model', model, '-src_dir', src_dir])

       # print('emojis2')
       #  for i in range(len(emojis_2)):
       #      prompt = emojis_2[i]
       #      print(f'prompt:{prompt}')
       #
       #      subprocess.call(['python', 'rank_lister.py', '-prompt', prompt, '-model', model, '-src_dir', src_dir])

        # print('emoji descriptions')
        # for i in range(len(emoji_descriptions)):
        #     prompt = emojis[i]
        #     print(f'prompt:{prompt}')
        #
        #     subprocess.call(['python','rank_lister.py','-prompt',prompt,'-model',model,'-src_dir',src_dir])
        #
        # print('variations')
        # for i in range(len(variations)):
        #     prompt = variations[i]
        #     print(f'prompt:{prompt}')
        #
        #     subprocess.call(['python','rank_lister.py','-prompt',prompt,'-model',model,'-src_dir',src_dir])


    # print('emojis')
    # for i in range(len(emojis)):
    #     prompt = emojis[i]
    #     print(f'prompt:{prompt}')
    #
    #     sp_args = ['python', 'rank_lister.py', '-prompt', prompt, '-model', model, '-compare_prompts']
    #
    #     sp_args.extend(cmp_prompts)
    #
    #     subprocess.call(sp_args)
    #
    # print('emoji descriptions')
    # for i in range(len(emoji_descriptions)):
    #     prompt = emojis[i]
    #     print(f'prompt:{prompt}')
    #
    #     sp_args = ['python', 'rank_lister.py', '-prompt', prompt, '-model', model, '-compare_prompts']
    #
    #     sp_args.extend(cmp_prompts)
    #
    #     subprocess.call(sp_args)
    #
    # print('variations')
    # for i in range(len(variations)):
    #     prompt = variations[i]
    #     print(f'prompt:{prompt}')
    #
    #
    #     sp_args = ['python', 'rank_lister.py', '-prompt', prompt, '-model', model, '-compare_prompts']
    #
    #     sp_args.extend( cmp_prompts)
    #
    #     subprocess.call(sp_args)




