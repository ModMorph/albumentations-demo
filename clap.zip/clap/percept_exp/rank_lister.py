import torch
import numpy as np
import pandas as pd
import PIL.Image
import PIL.ImageFile
import scipy.ndimage
import clip
import argparse
import sys
import torchvision.transforms as transforms
import os
from torchvision.datasets import ImageFolder


PIL.ImageFile.LOAD_TRUNCATED_IMAGES = True # avoid "Decompressed Data Too Large" error


class CLIPLoss(torch.nn.Module):

    def __init__(self):
        super(CLIPLoss, self).__init__()
        self.model, self.preprocess = clip.load("ViT-B/32", device="cuda")
        #self.upsample = torch.nn.Upsample(scale_factor=7)
        #self.avg_pool = torch.nn.AvgPool2d(kernel_size=32)

        self.res_model, self.res_preprocess = clip.load("RN50x4", device="cuda")


    def forward(self, image, text):
        #image = self.avg_pool(self.upsample(image))
        print(f'{image.size()} {text.size()}')
        similarity1 = self.model(image, text)[0] / 100 #[0] 1 -

        similarity2 = self.res_model(image, text)[0] / 100 #[0] 1 -

        similarity = similarity1 * .5 + similarity2 * .5

        return similarity





def get_similarities_4_images(src_dir, prompt,batch_size, model_name):
    filenames = []
    similarities = []

    transform = {
        'test': transforms.Compose([
            transforms.Resize([288, 288]),  # Resizing the image as the VGG only take 224 x 244 as input size

            # TODO if it is needed, add the random crop
            transforms.ToTensor()
        ])}


    print('Recreating aligned images...')

        #shutil.copyfile('LICENSE.txt', os.path.join(dst_dir, 'LICENSE.txt'))



    text_inputs = torch.cat([clip.tokenize(prompt)]).cuda()
    print(text_inputs.size())

    #text_inputs = text_inputs.repeat(batch_size,1)
    #print(text_inputs.size())

    print(f'prompt={prompt}, tokens={text_inputs}')


    print(f'src_dir={src_dir} ')
    images = [os.path.join(src_dir,f) for f in os.listdir(src_dir) if f.endswith('png') or f.endswith('jpg') or f.endswith('jpeg')]

    #folderDataset = ImageFolder(src_dir, transform=transform['test'] )
    #data_loader = torch.utils.data.DataLoader(dataset=folderDataset, batch_size=batch_size, shuffle=False, num_workers=4, drop_last=True)

    item_idx=0
    res_model, res_preprocess = clip.load(model_name, device="cuda:0")

    with torch.no_grad():
        image_mean = torch.tensor([0.48145466, 0.4578275, 0.40821073]).cuda()
        image_std = torch.tensor([0.26862954, 0.26130258, 0.27577711]).cuda()


        for z in range(len(images)):
            _images = []
            my_image = images[z]

            try:
                image = res_preprocess(PIL.Image.open(my_image).convert("RGB")) #)

                _images.append(image)
                #results = clip_loss(image , text_inputs.squeeze(0))

                image_input = torch.tensor(np.stack(_images)).cuda()
                image_input -= image_mean[:, None, None]
                image_input /= image_std[:, None, None]

                image_features = res_model.encode_image(image_input)
                text_features = res_model.encode_text(text_inputs)

                print(f'image_features = {image_features} {image_features.size()}')
                print(f'text_features = {text_features} {text_features.size()}')

                image_features /= image_features.norm(dim=-1, keepdim=True)
                text_features /= text_features.norm(dim=-1, keepdim=True)

                print(f'normed image_features = {image_features} {image_features.size()}')
                print(f'normed text_features = {text_features} {text_features.size()}')
                similarity = text_features.cpu().numpy() @ image_features.cpu().numpy().T
                print(f'{my_image} : {similarity}')
                filenames.append(my_image)
                similarities.append( similarity.item() )
            except Exception:
                print(f'err on img={my_image}')
                pass

        # print(dir(clip_loss))
        #
        # for i in range(len(folderDataset)//batch_size):
        #     print(f'{i} batch')
        #     batch_x, batch_y = next(iter(data_loader))
        #
        #     print(f'{batch_x.size()}')
        #     results = clip_loss(batch_x, text_inputs)
        #
        #     results = results.detach().numpy().tolist()
        #     #results=[]
        #
        #     #for j in range(len(batch_x)):
        #         #my_image = batch_x[j].unsqueeze(1)
        #
        #         #result = clip_loss(my_image, text_inputs)
        #         #print(result)
        #         #results.append(result.item())
        #
        #
        #     while len(results) > 0:
        #
        #         my_sim = results.pop(0)
        #         last_image = images.pop(0)
        #
        #         print(f'last_image={last_image} sim={my_simg}')
        #
        #         filenames.append(last_image)
        #         similarity.append(my_sim)


    return filenames, similarities



def get_similarities_4_text(comps, prompt,batch_size, model_name):
    filenames = []
    similarities = []



    text_inputs = torch.cat([clip.tokenize(prompt)]).cuda()
    print(text_inputs.size())

    #text_inputs = text_inputs.repeat(batch_size,1)
    #print(text_inputs.size())

    print(f'prompt={prompt}, tokens={text_inputs}')

    item_idx=0
    res_model, res_preprocess = clip.load(model_name, device="cuda:0")

    with torch.no_grad():

        text_features = res_model.encode_text(text_inputs)

        text_features /= text_features.norm(dim=-1, keepdim=True)


        for z in range(len(comps)):

            my_txt = comps[z]

            try:

                text_inputs2 = torch.cat([clip.tokenize(my_txt)]).cuda()
                text_features2 = res_model.encode_text(text_inputs2 )
                text_features2 /= text_features2.norm(dim=-1, keepdim=True)
                #results = clip_loss(image , text_inputs.squeeze(0))


                similarity = text_features.cpu().numpy() @ text_features2.cpu().numpy().T
                print(f'{my_txt} : {similarity}')
                filenames.append(my_txt)
                similarities.append( similarity.item() )
            except Exception:
                print(f'err on img={my_txt}')
                pass

        # print(dir(clip_loss))
        #
        # for i in range(len(folderDataset)//batch_size):
        #     print(f'{i} batch')
        #     batch_x, batch_y = next(iter(data_loader))
        #
        #     print(f'{batch_x.size()}')
        #     results = clip_loss(batch_x, text_inputs)
        #
        #     results = results.detach().numpy().tolist()
        #     #results=[]
        #
        #     #for j in range(len(batch_x)):
        #         #my_image = batch_x[j].unsqueeze(1)
        #
        #         #result = clip_loss(my_image, text_inputs)
        #         #print(result)
        #         #results.append(result.item())
        #
        #
        #     while len(results) > 0:
        #
        #         my_sim = results.pop(0)
        #         last_image = images.pop(0)
        #
        #         print(f'last_image={last_image} sim={my_simg}')
        #
        #         filenames.append(last_image)
        #         similarity.append(my_sim)


    return filenames, similarities



def run_cmdline(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument('-src_dir', '--src_dir',help='directory containing images to rank', nargs='+', default=[])
    #parser.add_argument('-dst_dir', '--dst_dir', help='output directory for rank list', type=str, default='.')
    parser.add_argument('-prompt','--prompt',help='prompt to rank images by',type=str, default='square')
    parser.add_argument('-batch_size', '--batch_size', help='prompt to rank images by', type=int, default=32)
    parser.add_argument('-model','--model',help='clip model to use',choices=clip.available_models(),type=str, default="ViT-B/32")
    parser.add_argument('-compare_prompts', '--compare_prompts',help='prompts to compare against prompt.', nargs='+', default=[])

    args = parser.parse_args()

    i=0

    filepaths = []
    similarity = []

    print(args)

    src=None

    if len(args.src_dir) > 0:
        for src in args.src_dir:

            print(f'src={src}')

            fnames, sims = get_similarities_4_images(src,args.prompt,args.batch_size, args.model)

            if len(fnames) > 0:
                filepaths.extend(fnames)

            if len(sims) > 0:
                similarity.extend(sims)
    elif len(args.compare_prompts) > 0:
        fnames, sims = get_similarities_4_text(args.compare_prompts,args.prompt,args.batch_size, args.model)

        src='txt2txtcmp'

        if len(fnames) > 0:
            filepaths.extend(fnames)

        if len(sims) > 0:
            similarity.extend(sims)








    if len(filepaths) > 0:
        df = pd.DataFrame({'filepaths':filepaths,'similarity':similarity})
        out_filename = args.prompt.replace("'","")
        out_filename += src.replace("//","_").replace("\\","").replace('/','_')
        out_filename += "_" + args.model.replace("//","_").replace('/','_')
        df.sort_values('similarity',ascending=False).to_csv(f'{out_filename}.csv')
    else:
        print('No files found for comparison')




if __name__ == "__main__":
    print('hello')
    run_cmdline(sys.argv)



