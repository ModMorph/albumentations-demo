import numpy as np
import pandas as pd
import os
import glob

import emojis as em





emojis = ['⬛','⬜','◼','◻','◾','◽','▪','▫']

#Flags with tricolors, bicolors unicolors or related patterns with quickly calculable surface area ratios for colors.

#Brown, Purple, Blue, Green, Yellow, Orange, Red Squares, White Square Button, Black Square Button, Checkered Flag,Black Flag, White Flag, Red Flag, Rainbow Flag, French Flag, Guinea Flag, Hungary Flag, Irish Flag, Italian Flag, Luxembourg Flag, Monaco, Saint Martin,Mauritius,Netherlands, Peru, Panama, POland, Romania, Russia, Sierra Leone,Thailand,Ukraine,Yemen, flag: Vietnam, Mali, Lithuania, Greenland, Gabon, Estonia, Germany, Clipperton Island, Colombia, Côte d’Ivoire, Congo - Brazzaville,Benin, Bulgaria,Belgium, Austria, Armenia, Large Blue Diamond, Small Blue Diamond, Hollow Red Circle,Stop Button, Drop of Blood, Bar Chart, Diamond Suit, Star, Stop Sign, Red Apple, Record Button, Black Circle, White Circle, Orange Circle
emojis_2 = ['🟫','🟪','🟦','🟩','🟨','🟧','🟥','🔳','🔲','🏁','🏴','🏳','🚩','🏳️‍🌈','🇫🇷','🇬🇳','🇭🇺','🇮🇩','🇮🇪','🇮🇹','🇱🇺','🇲🇨','🇲🇫','🇲🇺','🇳🇬','🇳🇱','🇵🇪','🇵🇦','🇵🇱','🇷🇴','🇷🇺','🇸🇱','🇹🇭','🇺🇦','🇾🇪','🇻🇳','🇲🇱','🇱🇹','🇬🇱','🇬🇦', '🇪🇪','🇩🇪','🇨🇵','🇨🇴','🇨🇮','🇨🇬','🇧🇯','🇧🇬','🇧🇪','🇦🇹','🇦🇲','🔷','🔹','⭕','⏹','🩸','📊','♦','⭐','🛑','🍎','⏺','⚫','⚪','🟠']


emoji_descriptions=['Black Large Square','White Large Square','Black Medium Square','White Medium Square','Black Medium-Small Square','White Medium-Small Square','Black Small Square','White Small Square']


variations = ['Black Square','White Square','Grey Square','Tiny Square','Small Square','Medium-Small Square','Medium Square','Large Square','Big Square','Green Square','Red Square','Blue Square',
              'Yellow Square','White','Black','Grey','Red','Green','Yellow','Blue','Rectangle','Quadrilateral','Tiny','Small','Medium','Medium-Small',
              'Large','Big','Giant','Line','Polygon','Circle','Triangle','Center','Left','Right','Top','Bottom']


emptyset = ['']


combined =[]

combined.extend(emojis)
combined.extend(emojis_2)
combined.extend(emoji_descriptions)
combined.extend(variations)
#combined.extend(emptyset)

# for i in range(len(combined)):
#     character = combined[i]
#     print(character)
#     rnlist = glob.glob(f'./RN101/{character}*.csv')
#
#     if len(rnlist) < 2:
#         continue
#
#     new_df = pd.read_csv(rnlist[0])
#
#     for j in range(1,len(rnlist)):
#         append_df = pd.read_csv(rnlist[j])
#         new_df=pd.concat([new_df,append_df],axis=0)
#
#
#     new_df.to_csv(f'combined_{character}_RN101.csv')
#
#     rnlist = glob.glob(f'./ViT-B_32/{character}*.csv')
#
#     if len(rnlist) < 2:
#         continue
#
#     new_df = pd.read_csv(rnlist[0])
#
#     for j in range(1, len(rnlist)):
#         append_df = pd.read_csv(rnlist[j])
#         new_df = pd.concat([new_df, append_df], axis=0)
#
#     new_df.to_csv(f'combined_{character}_ViT-B_32.csv')
#
#
#
#     print(rnlist)


primary_df = pd.read_csv('square_key.csv', encoding='utf-8')


secondary_df = pd.read_csv('square_key.csv', encoding='utf-8')

for i in range(len(combined)):
    character = combined[i]
    print(character)
    rnlist = glob.glob(f'./combined_{character}_ViT-B_32.csv')

    if len(rnlist) < 1:
        print('notfound')
        continue

    vit_df = pd.read_csv(rnlist[0], encoding='utf-8')

    decoded_char = em.decode(character)
    col_name = f'{decoded_char} similarity'
    vit_df  = vit_df.rename(columns={'similarity': col_name})

    primary_df=pd.merge(primary_df, vit_df[['filepaths',col_name]], on="filepaths",how="left")

    rnlist2 = glob.glob(f'./combined_{character}_RN101.csv')

    if len(rnlist2) < 1:
        print('notfound')
        continue

    rn_df = pd.read_csv(rnlist2[0], encoding='utf-8')

    rn_df = rn_df.rename(columns={'similarity': col_name})

    secondary_df=pd.merge(secondary_df, rn_df[['filepaths',col_name]], on="filepaths",how="left")



    #print(vit_df.describe())
    #print(rn_df.describe())



primary_df.to_csv('vit_sim.csv')
secondary_df.to_csv('rn101_sim.csv')
