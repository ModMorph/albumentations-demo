import numpy as np
import cv2





img = cv2.imread(r'C:\Users\Administrator\Pictures\fg_w.jpg')

mask_img = cv2.imread(r'C:\Users\Administrator\Pictures\baldie_black_swhite.jpg')

my_img = np.copy(img)

print(my_img.dtype)

print(my_img.shape)

new_img = np.ones(my_img.shape,dtype=np.uint8) * 255

mask_elements = np.argwhere(mask_img[:,:,0] == 255)

opposite_elements = np.argwhere(mask_img[:,:,0] == 0)

print(mask_elements)
print(mask_elements.shape)

new_img_idx = np.random.permutation(mask_elements)
#print new index

print('new index')
print(new_img_idx)
print(new_img_idx.shape)


#new_img[new_img_idx[:,1], new_img_idx[:,0], :] = my_img[mask_elements[:,1], mask_elements[:,0], :]

# for i in range(len(mask_elements)):
#
#     my_elem = mask_elements[i]
#     new_elem = new_img_idx[i]
#
#     #new_img[new_elem[0], new_elem[1], :] = np.copy(img[my_elem[0], my_elem[1], :])
#     #new_img[new_elem[0],new_elem[1],:] = np.copy(img[my_elem[0],my_elem[1],:])
#
#     #new_img[my_elem[0], my_elem[1], :] = np.copy(img[new_elem[0], new_elem[1], :])
#     #new_img[my_elem[0], my_elem[1], :] = np.copy(mask_img[new_elem[0], new_elem[1], :])
#     new_img.itemset((new_elem[0], new_elem[1],0), my_img[my_elem[0], my_elem[1],0] )
#     new_img.itemset((new_elem[0], new_elem[1], 1), my_img[my_elem[0], my_elem[1], 1])
#     new_img.itemset((new_elem[0], new_elem[1], 2), my_img[my_elem[0], my_elem[1], 2])


for i in range(len(opposite_elements)):

    #my_elem =
    new_elem = opposite_elements[i]

    #new_img[new_elem[0], new_elem[1], :] = np.copy(img[my_elem[0], my_elem[1], :])
    #new_img[new_elem[0],new_elem[1],:] = np.copy(img[my_elem[0],my_elem[1],:])

    #new_img[my_elem[0], my_elem[1], :] = np.copy(img[new_elem[0], new_elem[1], :])
    #new_img[my_elem[0], my_elem[1], :] = np.copy(mask_img[new_elem[0], new_elem[1], :])

    source_idx = np.random.randint(0,len(new_img_idx)-1)




    new_img.itemset((new_elem[0], new_elem[1],0), my_img[new_img_idx[source_idx][0], new_img_idx[source_idx][1],0] )
    new_img.itemset((new_elem[0], new_elem[1], 1), my_img[new_img_idx[source_idx][0], new_img_idx[source_idx][1], 1])
    new_img.itemset((new_elem[0], new_elem[1], 2), my_img[new_img_idx[source_idx][0], new_img_idx[source_idx][1], 2])

cv2.imshow('scramble_horizontal',my_img)
cv2.waitKey(2000)
cv2.imshow('scramble_horizontal',mask_img)
cv2.waitKey(2000)

cv2.imwrite('scramble_silohuette3invert.jpg',new_img)