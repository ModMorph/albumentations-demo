import numpy as np
import cv2





img = cv2.imread(r'C:\Users\Administrator\Pictures\fg_w.jpg')


my_img = np.copy(img)


print(my_img.shape)

new_img = np.zeros(my_img.shape,dtype=np.uint8)

new_img_idx = np.random.permutation(np.arange(my_img.shape[0]))
new_img_idx2 = np.random.permutation(np.arange(my_img.shape[1]))

print(new_img_idx)

if True:
    new_img[:, np.arange(my_img.shape[1]), :] = my_img[new_img_idx, :, :]
    new_img[np.arange(my_img.shape[0]), :, :] = my_img[:, new_img_idx2, :]

else:
    new_img[np.arange(my_img.shape[0]), np.arange(my_img.shape[1]), :] = my_img[new_img_idx, new_img_idx2, :]
    #my_img[np.arange(my_img.shape[0]),:,:] = my_img[new_img_idx,:,:]
    #my_img[:, np.arange(my_img.shape[1]), :] = my_img[new_img_idx2, :, :]


for i in range(len(new_img_idx)):

   for j in range(len(new_img_idx2)):

       old_i = new_img_idx[i]
       old_j = new_img_idx2[j]

       new_img[i,j,:] = my_img[old_i,old_j,:]




cv2.imshow('scramble_horizontal',new_img)

cv2.waitKey(2000)

cv2.imwrite('scramble_scramble2.jpg',new_img)