import streamlit as st
import pandas as pd
import numpy as np
from torchvision.transforms import Compose, Resize, CenterCrop, ToTensor, Normalize
from PIL import Image
import torch
import CLIP.clip as clip

import skimage
from collections import OrderedDict

from tempfile import NamedTemporaryFile
import pandas as pd

import gzip
import html
import os
from functools import lru_cache

import ftfy
import regex as re


@lru_cache()
def bytes_to_unicode():
    """
    Returns list of utf-8 byte and a corresponding list of unicode strings.
    The reversible bpe codes work on unicode strings.
    This means you need a large # of unicode characters in your vocab if you want to avoid UNKs.
    When you're at something like a 10B token dataset you end up needing around 5K for decent coverage.
    This is a signficant percentage of your normal, say, 32K bpe vocab.
    To avoid that, we want lookup tables between utf-8 bytes and unicode strings.
    And avoids mapping to whitespace/control characters the bpe code barfs on.
    """
    bs = list(range(ord("!"), ord("~")+1))+list(range(ord("¡"), ord("¬")+1))+list(range(ord("®"), ord("ÿ")+1))
    cs = bs[:]
    n = 0
    for b in range(2**8):
        if b not in bs:
            bs.append(b)
            cs.append(2**8+n)
            n += 1
    cs = [chr(n) for n in cs]
    return dict(zip(bs, cs))


def get_pairs(word):
    """Return set of symbol pairs in a word.
    Word is represented as tuple of symbols (symbols being variable-length strings).
    """
    pairs = set()
    prev_char = word[0]
    for char in word[1:]:
        pairs.add((prev_char, char))
        prev_char = char
    return pairs


def basic_clean(text):
    text = ftfy.fix_text(text)
    text = html.unescape(html.unescape(text))
    return text.strip()


def whitespace_clean(text):
    text = re.sub(r'\s+', ' ', text)
    text = text.strip()
    return text


def color_negative_red(val):
    """
    Takes a scalar and returns a string with
    the css property `'color: red'` for negative
    strings, black otherwise.
    """
    color = 'red' if val < 0 else 'blue'
    return 'color: %s' % color


def softmax(X, theta = 1.0, axis = None):
    """
    Compute the softmax of each element along an axis of X.

    Parameters
    ----------
    X: ND-Array. Probably should be floats.
    theta (optional): float parameter, used as a multiplier
        prior to exponentiation. Default = 1.0
    axis (optional): axis to compute values along. Default is the
        first non-singleton axis.

    Returns an array the same size as X. The result will sum to 1
    along the specified axis.
    """

    # make X at least 2d
    y = np.atleast_2d(X)

    # find axis
    if axis is None:
        axis = next(j[0] for j in enumerate(y.shape) if j[1] > 1)

    # multiply y against the theta parameter,
    y = y * float(theta)

    # subtract the max for numerical stability
    y = y - np.expand_dims(np.max(y, axis = axis), axis)

    # exponentiate y
    y = np.exp(y)

    # take the sum along the specified axis
    ax_sum = np.expand_dims(np.sum(y, axis = axis), axis)

    # finally: divide elementwise
    p = y / ax_sum

    # flatten if X was 1D
    if len(X.shape) == 1: p = p.flatten()

    return p

class SimpleTokenizer(object):
    def __init__(self, bpe_path: str = "bpe_simple_vocab_16e6.txt.gz"):
        self.byte_encoder = bytes_to_unicode()
        self.byte_decoder = {v: k for k, v in self.byte_encoder.items()}
        merges = gzip.open(bpe_path).read().decode("utf-8").split('\n')
        merges = merges[1:49152-256-2+1]
        merges = [tuple(merge.split()) for merge in merges]
        vocab = list(bytes_to_unicode().values())
        vocab = vocab + [v+'</w>' for v in vocab]
        for merge in merges:
            vocab.append(''.join(merge))
        vocab.extend(['<|startoftext|>', '<|endoftext|>'])
        self.encoder = dict(zip(vocab, range(len(vocab))))
        self.decoder = {v: k for k, v in self.encoder.items()}
        self.bpe_ranks = dict(zip(merges, range(len(merges))))
        self.cache = {'<|startoftext|>': '<|startoftext|>', '<|endoftext|>': '<|endoftext|>'}
        self.pat = re.compile(r"""<\|startoftext\|>|<\|endoftext\|>|'s|'t|'re|'ve|'m|'ll|'d|[\p{L}]+|[\p{N}]|[^\s\p{L}\p{N}]+""", re.IGNORECASE)

    def bpe(self, token):
        if token in self.cache:
            return self.cache[token]
        word = tuple(token[:-1]) + ( token[-1] + '</w>',)
        pairs = get_pairs(word)

        if not pairs:
            return token+'</w>'

        while True:
            bigram = min(pairs, key = lambda pair: self.bpe_ranks.get(pair, float('inf')))
            if bigram not in self.bpe_ranks:
                break
            first, second = bigram
            new_word = []
            i = 0
            while i < len(word):
                try:
                    j = word.index(first, i)
                    new_word.extend(word[i:j])
                    i = j
                except:
                    new_word.extend(word[i:])
                    break

                if word[i] == first and i < len(word)-1 and word[i+1] == second:
                    new_word.append(first+second)
                    i += 2
                else:
                    new_word.append(word[i])
                    i += 1
            new_word = tuple(new_word)
            word = new_word
            if len(word) == 1:
                break
            else:
                pairs = get_pairs(word)
        word = ' '.join(word)
        self.cache[token] = word
        return word

    def encode(self, text):
        bpe_tokens = []
        text = whitespace_clean(basic_clean(text)).lower()
        for token in re.findall(self.pat, text):
            token = ''.join(self.byte_encoder[b] for b in token.encode('utf-8'))
            bpe_tokens.extend(self.encoder[bpe_token] for bpe_token in self.bpe(token).split(' '))
        return bpe_tokens

    def decode(self, tokens):
        text = ''.join([self.decoder[token] for token in tokens])
        text = bytearray([self.byte_decoder[c] for c in text]).decode('utf-8', errors="replace").replace('</w>', ' ')
        return text


rsim =None
sim = None

preprocess =None

st.title('CLAP 4 CLIP')
st.markdown('Query CLIP and then **clap** for CLIP. Put on your contrastive glasses.')

add_selectbox = st.sidebar.selectbox('What do you wanna do?',('Rank Prompts for an Image','Rank Image versus Emojis','Rank Image versus Maxcodes', 'Rank Images by a Prompt','Rank Closest Images to another Image','Rank Closest Prompt to another Prompt','Classify an Image'))

#😂 ❤️
st.set_option('deprecation.showfileUploaderEncoding', False)


clip_model_selection = st.sidebar.selectbox('CLIP model do you want to use? Recommend RN50X4 or ViT-B/32',(clip.available_models()))


#model, preprocessor =

if clip_model_selection == 'RN50' or clip_model_selection == 'RN101':
    model = None

else:
    model, preprocess = clip.load(clip_model_selection, jit=False)
    #print(model)
    model.cuda().eval()
    # input_resolution = model.input_resolution.item()
    # context_length = model.context_length.item()
    # vocab_size = model.vocab_size.item()
    #
    # st.sidebar.text(f'input resolution = {input_resolution}')
    # st.sidebar.text(f'context length = {context_length}')
    # st.sidebar.text(f'vocab size = {vocab_size}')

    # preprocess = Compose([
    #     Resize(input_resolution, interpolation=Image.BICUBIC),
    #     CenterCrop(input_resolution),
    #     ToTensor()
    # ])




image = None
images = []

right_images = []

txt_features=None

img_features=None
rimg_features=None

left_mask = None
right_mask = None

lmask_features=None
rmask_features=None


#Chihuahua; pizza; pretzel; broccoli; hot dog; Boston Terrier; French Bulldog;spatula;Italian Greyhound;Miniature Pinscher;Griffon Bruxellois;West Highland White Terrier;Schipperke;Maltese;Australian Terrier; hotdog;

def get_random_image(right_cmp=False):

    rand_arr=np.random.randint(0,256,(288,288,3), dtype=np.uint8)
    my_img = Image.fromarray(rand_arr)
    image = preprocess(my_img)
    # image = preprocess(Image.open(os.path.join(skimage.data_dir, filename)).convert("RGB"))

    if right_cmp:
        right_images.append(image)
    else:
        images.append(image)

    return my_img

def load_image(upload, right_cmp=False):

    if upload is not None:
        my_img = Image.open(upload).convert("RGB")
        image = preprocess(my_img )
        #image = preprocess(Image.open(os.path.join(skimage.data_dir, filename)).convert("RGB"))

        if right_cmp:
            if len(right_images) > 0:
                right_images.pop()

            right_images.append(image)
        else:
            if len(images) > 0:
                images.pop()

            images.append(image)

    return my_img

cmp_cossim =None
self_l_cossim = None
self_r_cossim = None



st.beta_container()
col1, col2 = st.beta_columns([2,2])


col1.subheader('Left Image')
col2.subheader('Right Image')

lnoise_button=col1.button('Random Noise LImage')
rnoise_button = col2.button('Random Noise RImage')


if lnoise_button:
    rand_img =get_random_image()
    col1.image(rand_img)

if rnoise_button:
    rand_img =get_random_image(True)
    col2.image(rand_img)

if img_features is not None and rimg_features is not None:

    cmp_cossim = img_features @ rimg_features.T[:,:,0]
    self_l_cossim = img_features @ img_features.T[:,:,0]
    self_r_cossim = rimg_features @ rimg_features.T[:,:,0]
    print(f'Dot Product LImage . RImage = {cmp_cossim}')
    print(f'L Selfcossim = {self_l_cossim}, R Selfcossim = {self_r_cossim}')

    col1.text(f'L Selfcossim = {self_l_cossim}')
    col2.text(f'L Selfcossim = {self_r_cossim}')



if add_selectbox == 'Rank Prompts for an Image' or add_selectbox =='Rank Images by a Prompt' or add_selectbox == 'Classify an Image' \
        or add_selectbox=='Rank Image versus Emojis' or add_selectbox=='Rank Image versus Maxcodes':


   # if add_selectbox =='Rank Images by a Prompt':
    #    multiple_files = True
    #    upload_prompt='Choose or paste image(s)...'
    #    st.header('Rank Images by a Prompt')
    #else:
    multiple_files = False
    upload_prompt = 'Choose or paste an image...'

    uploaded_file = col1.file_uploader(upload_prompt,  type=["jpg","png","jpeg"], accept_multiple_files=multiple_files,key='left_upload')

    if uploaded_file is not None:
        #image = Image.open(uploaded_file)
        print(uploaded_file.type)
        print(uploaded_file.name)

        temp_file = NamedTemporaryFile(delete=False, suffix=uploaded_file.name)
        if not isinstance(uploaded_file, list):
            #temp_file.write(uploaded_file.getvalue())
            col1.image(load_image(uploaded_file))
        else:
            for item in uploaded_file:

                if item is None:
                    continue
                temp_file = NamedTemporaryFile(delete=False, suffix=item.name)
                temp_file.write(item.getvalue())
                #st.write(load_image(uploaded_file))

                col1.image(load_image(temp_file.name), )

        # data = uploaded_file.read()
        # st.image(image, caption='Uploaded Image.', use_column_width=True)
        # st.write("")
        # st.write("Analyzing...")
        # label = predict(uploaded_file)
        # st.write('%s (%.2f%%)' % (label[1], label[2] * 100))
    uploaded_file2 = col2.file_uploader(upload_prompt, type=["jpg", "png", "jpeg"], accept_multiple_files=multiple_files,key='right_upload')

    if uploaded_file2 is not None:
        # image = Image.open(uploaded_file)
        print(uploaded_file2.type)
        print(uploaded_file2.name)

        temp_file = NamedTemporaryFile(delete=False, suffix=uploaded_file2.name)
        if not isinstance(uploaded_file2, list):
            # temp_file.write(uploaded_file.getvalue())
            col2.image(load_image(uploaded_file2,True))
        else:
            for item in uploaded_file2:

                if item is None:
                    continue
                temp_file = NamedTemporaryFile(delete=False, suffix=item.name)
                temp_file.write(item.getvalue())
                # st.write(load_image(uploaded_file))

                col2.image(load_image(temp_file.name, True))

text_prefix_input = st.sidebar.text_input('Enter any prefix added to all text prompts')

text_input_box  = st.sidebar.text_area('Enter a text prompt, separated by semi-colon')

text_suffix_input = st.sidebar.text_input('Enter any suffix added to all text prompts')


save_q = st.sidebar.button('Save Query')
reset_q = st.sidebar.button('Reset Query')

if save_q:
    query_name = st.sidebar.text_input('Enter query name.')

    if query_name != '':
        print('saved')
        pass

if reset_q:
    text_prefix_input=None
    text_input_box=None
    text_suffix_input=None


if model is not None and images is not None and text_input_box is not None:




    image_mean = torch.tensor([0.48145466, 0.4578275, 0.40821073]).cuda()
    image_std = torch.tensor([0.26862954, 0.26130258, 0.27577711]).cuda()

    image_input = torch.tensor(np.stack(images)).cuda()
    image_input -= image_mean[:, None, None]
    image_input /= image_std[:, None, None]

    with torch.no_grad():
        image_features = model.encode_image(image_input).float()
        #image_features /= image_features.norm(dim=-1, keepdim=True)
        print(f'features size = {image_features.size()}')
        col2.write(image_features.shape)
        img_features = image_features.cpu().numpy()
        #col2.write(img_features)

if model is not None and right_images is not None and text_input_box is not None:




    image_mean = torch.tensor([0.48145466, 0.4578275, 0.40821073]).cuda()
    image_std = torch.tensor([0.26862954, 0.26130258, 0.27577711]).cuda()

    image_input = torch.tensor(np.stack(right_images)).cuda()
    image_input -= image_mean[:, None, None]
    image_input /= image_std[:, None, None]

    with torch.no_grad():
        rimage_features = model.encode_image(image_input).float()
        #rimage_features /= rimage_features.norm(dim=-1, keepdim=True)

        col1.write(rimage_features.shape)
        rimg_features = rimage_features.cpu().numpy()


if model is not None and (images is not None or right_images is not None) and text_input_box is not None and image_features is not None and add_selectbox != 'Rank Image versus Emojis' and add_selectbox != 'Rank Image versus Maxcodes':

    tokenizer = SimpleTokenizer()
    text_tokens = [tokenizer.encode(text_prefix_input + desc.strip() + text_suffix_input) for desc in text_input_box.split(';')]
    text_strings = [text_prefix_input.lower() + desc.strip().lower() + text_suffix_input.lower() for desc in text_input_box.split(';')]

    low=0
    high=49408
    #x = torch.distributions.uniform.Uniform(low, high)

    #model.context_length.item()
    rando_query = np.random.randint(low,high,(len(text_tokens), 512),dtype=np.int64)

    #text_input = torch.from_numpy(rando_query)

    text_input = torch.zeros(len(text_tokens), model.context_length, dtype=torch.long)
    sot_token = tokenizer.encoder['<|startoftext|>']
    eot_token = tokenizer.encoder['<|endoftext|>']




    #text_input[:,0]=sot_token
    #text_input[:, 0] =sot_token
    #text_input[:, 1] = 4000
    #text_input[:, 2] = eot_token
    # text_input[:, 4] = sot_token
    # text_input[:, 5] = 5
    # text_input[:, 6] =eot_token
    #text_input[:, 3:]=0
    # text_input[:,2]=sot_token
    # text_input[:, 3] = sot_token
    # text_input[:, 5] = eot_token
    # text_input[:, 6] = sot_token
    # text_input[:, 8] = eot_token
    # text_input[:, 9] = sot_token
    # text_input[:, 10] = eot_token
    # text_input[:, 11] = sot_token
    # text_input[:, 13] = eot_token
    # text_input[:, 14] = sot_token
    # text_input[:, 16] = eot_token
    # text_input[:, 17] = sot_token
    # text_input[:, 19] = eot_token
    # text_input[:, 20] = sot_token
    #text_input[:,2:]=0
    #text_input[:, -1] = eot_token
    for i, tokens in enumerate(text_tokens):
        tokens = [sot_token] + tokens + [eot_token]
        text_input[i, :len(tokens)] = torch.tensor(tokens)
    print(rando_query)
    print(rando_query.shape)
    text_input = text_input.cuda()

    with torch.no_grad():

        text_features = model.encode_text(text_input).float()

    text_features /= text_features.norm(dim=-1, keepdim=True)

    txt_features = text_features.cpu().numpy()

    selfsim_txt =  100 * txt_features @ txt_features.T

    selfsim_cols = ['_text_','_prompt_']



    for z in range(len(text_strings)):
        selfsim_cols.append(text_strings[z])

    selfsimtxt = pd.DataFrame(columns=selfsim_cols)

    for z in range(len(text_strings)):
        selfsimtxt[text_strings[z]] = selfsim_txt[z]

    #If there's text or prompt as keyword don't want conflict/bug.
    selfsimtxt['_text_'] = text_strings
    selfsimtxt['_prompt_'] = text_tokens
    #chart_data = pd.DataFrame(np.random.randn(1, len(text_strings)),columns=text_strings)

    #col1.bar_chart(data=chart_data, use_container_width=True) #,'similarity'
    st.sidebar.write(selfsimtxt)


if txt_features is not None and img_features is not None:

    print(f'txt_f {txt_features.shape} img_f {img_features.shape}')



    similarity = 100 * txt_features @ img_features.T[:,:,0]

   # score_list=[]
    #idx_score_list=[]
    image_g = np.zeros((7,7))
    for n in range(1, img_features.T.shape[2]):
        first_test = similarity - (100 * (txt_features @ img_features.T[:,:,n]))
        #idx_score_list.append(n)
        #score_list.append(np.sum(first_test).tolist())
        x=(n-1) % 7
        y=(n-1)//7

        image_g[y,x] = first_test

    import seaborn as sns
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots()

    col1.write(sns.heatmap(image_g, ax=ax))

    col1.pyplot(fig)

    col1.write(image_g)
    #col1.write({'index': idx_score_list, 'score': score_list})

    #soft_percent = softmax(similarity) #, 'softmax': soft_percent.flatten()

    sim = pd.DataFrame({'idx': range(0, len(text_strings)), 'text': text_strings, 'prompt': text_tokens,
                        'similarity': similarity.flatten()})

    col1.write(clip_model_selection)
#'softmax',
    styled_sim = sim[['text','similarity','prompt']].sort_values(
        'similarity', ascending=False)

    styled_sim.style.applymap(color_negative_red)

    col1.dataframe(styled_sim,width=1200)

    print(similarity.shape)
    print(similarity)
    print(text_strings)


if txt_features is not None and rimg_features is not None:
    print(f'txt_f {txt_features.shape} rimg_f {rimg_features.shape}')
    rsimilarity = 100 * txt_features @ rimg_features.T[:,:,0]

    image_g = np.zeros((7, 7))
    for n in range(1, rimg_features.T.shape[2]):
        first_test = rsimilarity - (100 * (txt_features @ rimg_features.T[:, :, n]))
        # idx_score_list.append(n)
        # score_list.append(np.sum(first_test).tolist())
        x = (n - 1) % 7
        y = (n - 1) // 7

        image_g[y, x] = first_test

    fig, ax = plt.subplots() #figsize=(10,10)

    col2.write(sns.heatmap(image_g, ax=ax))

    col2.pyplot(fig)
    #rsoft_percent = softmax(rsimilarity)

    rsim = pd.DataFrame({'idx': range(0, len(text_strings)), 'text': text_strings, 'prompt': text_tokens,
                        'similarity': rsimilarity.flatten()})  #, 'softmax': rsoft_percent.flatten()

    col2.write(clip_model_selection)

    col2.dataframe(rsim[['text','similarity','prompt']].sort_values(
        'similarity', ascending=False),width=1200) #'softmax',

    print(rsimilarity.shape)
    print(rsimilarity)
    print(text_strings)

if rsim is not None and sim is not None:
    left_diff= (sim['similarity'].values - rsim['similarity'].values)
    right_diff= (rsim['similarity'].values - sim['similarity'].values)

    #ldiff_soft_percent = softmax(left_diff)
    #rdiff_soft_percent = softmax(right_diff)

    ldiffsim = pd.DataFrame({'idx': range(0, len(text_strings)), 'text': text_strings, 'prompt': text_tokens,
                         'similarity': left_diff.flatten()}) #, 'softmax': ldiff_soft_percent.flatten()

    rdiffsim = pd.DataFrame({'idx': range(0, len(text_strings)), 'text': text_strings, 'prompt': text_tokens,
                             'similarity': right_diff.flatten()}) #, 'softmax': rdiff_soft_percent .flatten()

    col1.subheader('Left Diff')
    col1.write(ldiffsim[['text','similarity','prompt']].sort_values(
        'similarity', ascending=False) )
    col2.subheader('Right Diff')
    col2.write(rdiffsim[['text','similarity','prompt']].sort_values(
        'similarity', ascending=False) ) #'softmax',

# if sim is not None:
#     color_left = col1.color_picker('Pick a color mask to subtract', '#ffffff', key='lcolor')
#     print(color_left)
#     import struct
#
#     l_color = struct.unpack('BBB', bytes.fromhex(color_left.replace('#','')))
#
#     left_mask = np.ones((224,224,3),dtype=np.uint8)
#
#     left_mask[:, :, 0] *= l_color[0]
#     left_mask[:, :, 1] *= l_color[1]
#     left_mask[:, :, 2] *= l_color[2]
#
#     left_mask = Image.fromarray(left_mask)
#     left_mask = preprocess(left_mask)
#
#
#
#     image_mean = torch.tensor([0.48145466, 0.4578275, 0.40821073]).cuda()
#     image_std = torch.tensor([0.26862954, 0.26130258, 0.27577711]).cuda()
#
#     image_input = torch.tensor(np.stack([left_mask ])).cuda()
#     image_input -= image_mean[:, None, None]
#     image_input /= image_std[:, None, None]
#
#     with torch.no_grad():
#         lmask_features = model.encode_image(image_input).float()
#         print(f'lmask_features={lmask_features.size()}')
#         #lmask_features /= lmask_features.norm(dim=-1, keepdim=True)
#
#     lmask_features = lmask_features.cpu().numpy()
#
#     lcossim = img_features @ lmask_features.T
#
#     col1.write(f'Left Image Cosine Sim w/{color_left} ={lcossim}')
#
#     lmask_sim = 100. * lmask_features @ txt_features.T
#
#     #lmask_soft_percent = softmax(lmask_sim)
#
#
#     lmasksim = pd.DataFrame({'idx': range(0, len(text_strings)), 'text': text_strings, 'prompt': text_tokens,
#                              'similarity': lmask_sim.flatten()}) #, 'softmax': lmask_soft_percent.flatten()
#
#     col1.subheader(f'LImage - {color_left} Mask')
#     mleft_diff =  (sim['similarity'].values - lmasksim['similarity'].values)
#     #mleft_diff_softmax = softmax( mleft_diff)
#     adjusted_lsim = pd.DataFrame({'idx': range(0, len(text_strings)), 'text': text_strings, 'prompt': text_tokens,
#                              'similarity': mleft_diff.flatten()}) #, 'softmax': mleft_diff_softmax .flatten()
#
#
#     col1.write(adjusted_lsim[['text', 'similarity', 'prompt']].sort_values(
#         'similarity', ascending=False).style.highlight_max(axis=0)) # 'softmax',
#
#
#     col1.subheader(f'{color_left} vs. Prompt')
#
#     col1.write(lmasksim[['text','similarity','prompt']].sort_values(
#         'similarity', ascending=False) ) #'softmax',
#
#
# if rsim is not None:
#     color_right = col2.color_picker('Pick a color mask to subtract', '#ffffff', key='rcolor')
#     print(color_right)
#     import struct
#
#     r_color = struct.unpack('BBB', bytes.fromhex(color_right.replace('#','')))
#
#     right_mask = np.ones((model.input_resolution.item(), model.input_resolution.item(), 3),dtype=np.uint8)
#     right_mask[:, :, 0] *= r_color[0]
#     right_mask[:, :, 1] *= r_color[1]
#     right_mask[:, :, 2] *= r_color[2]
#     right_mask = Image.fromarray(right_mask)
#     right_mask = preprocess(right_mask)
#
#     image_mean = torch.tensor([0.48145466, 0.4578275, 0.40821073]).cuda()
#     image_std = torch.tensor([0.26862954, 0.26130258, 0.27577711]).cuda()
#
#     image_input = torch.tensor(np.stack([right_mask])).cuda()
#     image_input -= image_mean[:, None, None]
#     image_input /= image_std[:, None, None]
#
#     with torch.no_grad():
#         rmask_features = model.encode_image(image_input).float()
#         rmask_features /= rmask_features.norm(dim=-1, keepdim=True)
#
#     rmask_features = rmask_features.cpu().numpy()
#
#     rcossim = 100. * rimg_features @ rmask_features.T
#
#     col2.write(f'Right Image Cosine Sim w/{color_right} ={rcossim}')
#
#     rmask_sim = 100. * rmask_features @ txt_features.T
#
#     #rmask_soft_percent = softmax(rmask_sim)
#
#     rmasksim = pd.DataFrame({'idx': range(0, len(text_strings)), 'text': text_strings, 'prompt': text_tokens,
#                              'similarity': rmask_sim.flatten()}) #, 'softmax': rmask_soft_percent.flatten()
#
#
#     col2.subheader(f'RImage - {color_right} Mask')
#
#
#     mright_diff =( rsim['similarity'].values - rmasksim['similarity'].values)
#
#
#
#     #mright_diff_softmax = softmax(mright_diff)
#     adjusted_rsim = pd.DataFrame({'idx': range(0, len(text_strings)), 'text': text_strings, 'prompt': text_tokens,
#                                   'similarity': mright_diff.flatten()}) #, 'softmax': mright_diff_softmax.flatten()
#
#     col2.write(adjusted_rsim[['text', 'similarity',  'prompt']].sort_values(
#         'similarity', ascending=False)) #'softmax',
#
#     col2.subheader(f'{color_right} Mask vs. Prompt')
#
#     if color_left == color_right:
#         col2.write('<== same')
#     else:
#         col2.write(rmasksim[['text','similarity','softmax','prompt']].sort_values(
#         'similarity', ascending=False))

if model is not None and images is not None and text_input_box is not None:


    image_mean = torch.tensor([0.48145466, 0.4578275, 0.40821073]).cuda()
    image_std = torch.tensor([0.26862954, 0.26130258, 0.27577711]).cuda()

    image_input = torch.tensor(np.stack(images)).cuda()
    image_input -= image_mean[:, None, None]
    image_input /= image_std[:, None, None]

    with torch.no_grad():
        image_features = model.encode_image(image_input).float()
        image_features /= image_features.norm(dim=-1, keepdim=True)

        col2.write(image_features.shape)
        img_features = image_features.cpu().numpy()



if model is not None and images is not None and add_selectbox=='Rank Image versus Maxcodes' and image_features is not None:
    text_features = np.load('resx4maximaprompts.npy')


    #text_tensor = torch.HalfTensor(text_features)
    #similarity = text_tensor.cuda() @ image_features.T
    similarity =  np.mean(text_features[:,:,:512] @ image_features.cpu().numpy().T,axis=1)
    print(similarity.shape)
    #similarity = similarity.cpu().numpy()
    st.write(clip_model_selection)
    soft_percent = softmax(similarity)
#, sil;PP;FF;TH;DD;kk;CH;SS;nn;RR;aa;E;I;O;U
                      #
    sim = pd.DataFrame({ 'idx':range(0,len(similarity.flatten())),'similarity': similarity.flatten(),'softmax': soft_percent.flatten()}).sort_values('similarity',ascending=False)

    st.write(sim)
    st.bar_chart(data=sim[['text','similarity']], use_container_width=True)

if model is not None and images is not None and add_selectbox=='Rank Image versus Emojis' and image_features is not None:
    text_features = np.load('emoji_embedding.npy')
    prompts = np.load('npemoji.npy')
    #similarity = np.mean(text_features,axis=1) @ image_features.cpu().numpy().T
    similarity = np.mean(text_features[:,:,:512] @ image_features.cpu().numpy().T, axis=1)
    soft_percent = softmax(similarity)
    print(f'{prompts.shape} sim={similarity.shape} soft={soft_percent}')
#'prompts':prompts,
    sim = pd.DataFrame({ 'idx':range(0,len(similarity.flatten())), 'prompts':prompts,'similarity': similarity.flatten(),'softmax': soft_percent.flatten()
                        }).style.applymap(color_negative_red).sort_values('similarity',ascending=True)

    st.write(clip_model_selection)
    st.write(sim)
    st.bar_chart(data=sim[['text']], use_container_width=True) #,'similarity'

#st.balloons()

#person;man;woman;tv;🧑;👨;👩;📺;🍏;🍎;apple stem;iPod;iPod device;iPod factory;words;🍐;  iPod;iPod sign;iPod written on paper;poop written on paper;blank;blank paper;paper blank;apple;Granny Smith;Apple iPod;Apple Logo;3 Apple Logos;three apple logos;two apple logos;Pear;iPear; PearI;Orange;Grapes;🥭;red;green;red apple;green apple;shiny red apple;shiny green apple;shiny apple;la manzana;苹果;thing;fruit;vegetable;
#https://getemoji.com/
#https://blog.jcharistech.com/2020/07/31/building-a-calculator-with-streamlit-components-and-html/

    #st.write(prompts[639])
   #st.write(prompts[679])
    #st.write(prompts[1130])