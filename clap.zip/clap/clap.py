import streamlit as st
import pandas as pd
import numpy as np
from torchvision.transforms import Compose, Resize, CenterCrop, ToTensor, Normalize
from PIL import Image
import torch
import CLIP.clip as clip

import skimage
from collections import OrderedDict

from tempfile import NamedTemporaryFile
import pandas as pd

import gzip
import html
import os
from functools import lru_cache

import ftfy
import regex as re


@lru_cache()
def bytes_to_unicode():
    """
    Returns list of utf-8 byte and a corresponding list of unicode strings.
    The reversible bpe codes work on unicode strings.
    This means you need a large # of unicode characters in your vocab if you want to avoid UNKs.
    When you're at something like a 10B token dataset you end up needing around 5K for decent coverage.
    This is a signficant percentage of your normal, say, 32K bpe vocab.
    To avoid that, we want lookup tables between utf-8 bytes and unicode strings.
    And avoids mapping to whitespace/control characters the bpe code barfs on.
    """
    bs = list(range(ord("!"), ord("~")+1))+list(range(ord("¡"), ord("¬")+1))+list(range(ord("®"), ord("ÿ")+1))
    cs = bs[:]
    n = 0
    for b in range(2**8):
        if b not in bs:
            bs.append(b)
            cs.append(2**8+n)
            n += 1
    cs = [chr(n) for n in cs]
    return dict(zip(bs, cs))


def get_pairs(word):
    """Return set of symbol pairs in a word.
    Word is represented as tuple of symbols (symbols being variable-length strings).
    """
    pairs = set()
    prev_char = word[0]
    for char in word[1:]:
        pairs.add((prev_char, char))
        prev_char = char
    return pairs


def basic_clean(text):
    text = ftfy.fix_text(text)
    text = html.unescape(html.unescape(text))
    return text.strip()


def whitespace_clean(text):
    text = re.sub(r'\s+', ' ', text)
    text = text.strip()
    return text



def softmax(X, theta = 1.0, axis = None):
    """
    Compute the softmax of each element along an axis of X.

    Parameters
    ----------
    X: ND-Array. Probably should be floats.
    theta (optional): float parameter, used as a multiplier
        prior to exponentiation. Default = 1.0
    axis (optional): axis to compute values along. Default is the
        first non-singleton axis.

    Returns an array the same size as X. The result will sum to 1
    along the specified axis.
    """

    # make X at least 2d
    y = np.atleast_2d(X)

    # find axis
    if axis is None:
        axis = next(j[0] for j in enumerate(y.shape) if j[1] > 1)

    # multiply y against the theta parameter,
    y = y * float(theta)

    # subtract the max for numerical stability
    y = y - np.expand_dims(np.max(y, axis = axis), axis)

    # exponentiate y
    y = np.exp(y)

    # take the sum along the specified axis
    ax_sum = np.expand_dims(np.sum(y, axis = axis), axis)

    # finally: divide elementwise
    p = y / ax_sum

    # flatten if X was 1D
    if len(X.shape) == 1: p = p.flatten()

    return p

class SimpleTokenizer(object):
    def __init__(self, bpe_path: str = "bpe_simple_vocab_16e6.txt.gz"):
        self.byte_encoder = bytes_to_unicode()
        self.byte_decoder = {v: k for k, v in self.byte_encoder.items()}
        merges = gzip.open(bpe_path).read().decode("utf-8").split('\n')
        merges = merges[1:49152-256-2+1]
        merges = [tuple(merge.split()) for merge in merges]
        vocab = list(bytes_to_unicode().values())
        vocab = vocab + [v+'</w>' for v in vocab]
        for merge in merges:
            vocab.append(''.join(merge))
        vocab.extend(['<|startoftext|>', '<|endoftext|>'])
        self.encoder = dict(zip(vocab, range(len(vocab))))
        self.decoder = {v: k for k, v in self.encoder.items()}
        self.bpe_ranks = dict(zip(merges, range(len(merges))))
        self.cache = {'<|startoftext|>': '<|startoftext|>', '<|endoftext|>': '<|endoftext|>'}
        self.pat = re.compile(r"""<\|startoftext\|>|<\|endoftext\|>|'s|'t|'re|'ve|'m|'ll|'d|[\p{L}]+|[\p{N}]|[^\s\p{L}\p{N}]+""", re.IGNORECASE)

    def bpe(self, token):
        if token in self.cache:
            return self.cache[token]
        word = tuple(token[:-1]) + ( token[-1] + '</w>',)
        pairs = get_pairs(word)

        if not pairs:
            return token+'</w>'

        while True:
            bigram = min(pairs, key = lambda pair: self.bpe_ranks.get(pair, float('inf')))
            if bigram not in self.bpe_ranks:
                break
            first, second = bigram
            new_word = []
            i = 0
            while i < len(word):
                try:
                    j = word.index(first, i)
                    new_word.extend(word[i:j])
                    i = j
                except:
                    new_word.extend(word[i:])
                    break

                if word[i] == first and i < len(word)-1 and word[i+1] == second:
                    new_word.append(first+second)
                    i += 2
                else:
                    new_word.append(word[i])
                    i += 1
            new_word = tuple(new_word)
            word = new_word
            if len(word) == 1:
                break
            else:
                pairs = get_pairs(word)
        word = ' '.join(word)
        self.cache[token] = word
        return word

    def encode(self, text):
        bpe_tokens = []
        text = whitespace_clean(basic_clean(text)).lower()
        for token in re.findall(self.pat, text):
            token = ''.join(self.byte_encoder[b] for b in token.encode('utf-8'))
            bpe_tokens.extend(self.encoder[bpe_token] for bpe_token in self.bpe(token).split(' '))
        return bpe_tokens

    def decode(self, tokens):
        text = ''.join([self.decoder[token] for token in tokens])
        text = bytearray([self.byte_decoder[c] for c in text]).decode('utf-8', errors="replace").replace('</w>', ' ')
        return text




preprocess =None

st.title('CLAP 4 CLIP')
st.markdown('Query CLIP and then **clap** for CLIP. Sometimes golf claps. Other times no.')

add_selectbox = st.sidebar.selectbox('What do you wanna do?',('Rank Prompts for an Image','Rank Image versus Emojis','Rank Image versus Maxcodes', 'Rank Images by a Prompt','Rank Closest Images to another Image','Rank Closest Prompt to another Prompt','Classify an Image'))

#😂 ❤️
st.set_option('deprecation.showfileUploaderEncoding', False)


clip_model_selection = st.sidebar.selectbox('What CLIP model do you want to use? Recommend RN50X4 or ViT-B/32',(clip.available_models()))


#model, preprocessor =

if clip_model_selection == 'RN50' or clip_model_selection == 'RN101':
    model = None

else:
    model, preprocess = clip.load(clip_model_selection, jit=True)
    print(model)
    model.cuda().eval()
    input_resolution = model.input_resolution.item()
    context_length = model.context_length.item()
    vocab_size = model.vocab_size.item()

    # preprocess = Compose([
    #     Resize(input_resolution, interpolation=Image.BICUBIC),
    #     CenterCrop(input_resolution),
    #     ToTensor()
    # ])




image = None
images = []

def load_image(upload):

    if upload is not None:
        my_img = Image.open(upload).convert("RGB")
        image = preprocess(my_img )
        #image = preprocess(Image.open(os.path.join(skimage.data_dir, filename)).convert("RGB"))
        images.append(image)

    return my_img




if add_selectbox == 'Rank Prompts for an Image' or add_selectbox =='Rank Images by a Prompt' or add_selectbox == 'Classify an Image' \
        or add_selectbox=='Rank Image versus Emojis' or add_selectbox=='Rank Image versus Maxcodes':


    if add_selectbox =='Rank Images by a Prompt':
        multiple_files = True
        upload_prompt='Choose or paste image(s)...'
        st.header('Rank Images by a Prompt')
    else:
        multiple_files = False
        upload_prompt = 'Choose or paste an image...'

    uploaded_file = st.file_uploader(upload_prompt,  type=["jpg","png","jpeg"], accept_multiple_files=multiple_files)

    if uploaded_file is not None:
        #image = Image.open(uploaded_file)
        print(uploaded_file.type)
        print(uploaded_file.name)

        temp_file = NamedTemporaryFile(delete=False, suffix=uploaded_file.name)
        if not isinstance(uploaded_file, list):
            #temp_file.write(uploaded_file.getvalue())
            st.image(load_image(uploaded_file))
        else:
            for item in uploaded_file:

                if item is None:
                    continue
                temp_file = NamedTemporaryFile(delete=False, suffix=item.name)
                temp_file.write(item.getvalue())
                #st.write(load_image(uploaded_file))

                st.image(load_image(temp_file.name))

        # data = uploaded_file.read()
        # st.image(image, caption='Uploaded Image.', use_column_width=True)
        # st.write("")
        # st.write("Analyzing...")
        # label = predict(uploaded_file)
        # st.write('%s (%.2f%%)' % (label[1], label[2] * 100))


text_prefix_input = st.text_input('Enter any prefix added to all text prompts')

text_input_box  = st.text_input('Enter a text prompt, seperated by semi-colon')

text_suffix_input = st.text_input('Enter any suffix added to all text prompts')

if model is not None and images is not None and text_input_box is not None:




    image_mean = torch.tensor([0.48145466, 0.4578275, 0.40821073]).cuda()
    image_std = torch.tensor([0.26862954, 0.26130258, 0.27577711]).cuda()

    image_input = torch.tensor(np.stack(images)).cuda()
    image_input -= image_mean[:, None, None]
    image_input /= image_std[:, None, None]

    with torch.no_grad():
        image_features = model.encode_image(image_input).float()
        image_features /= image_features.norm(dim=-1, keepdim=True)

        st.write(image_features.shape)


if model is not None and images is not None and text_input_box is not None and image_features is not None and add_selectbox != 'Rank Image versus Emojis' and add_selectbox != 'Rank Image versus Maxcodes':

    tokenizer = SimpleTokenizer()
    text_tokens = [tokenizer.encode(text_prefix_input + desc.strip() + text_suffix_input) for desc in text_input_box.split(';')]
    text_strings = [text_prefix_input + desc.strip() + text_suffix_input for desc in text_input_box.split(';')]

    text_input = torch.zeros(len(text_tokens), model.context_length, dtype=torch.long)
    sot_token = tokenizer.encoder['<|startoftext|>']
    eot_token = tokenizer.encoder['<|endoftext|>']

    for i, tokens in enumerate(text_tokens):
        tokens = [sot_token] + tokens + [eot_token]
        text_input[i, :len(tokens)] = torch.tensor(tokens)

    text_input = text_input.cuda()

    with torch.no_grad():

        text_features = model.encode_text(text_input).float()

    text_features /= text_features.norm(dim=-1, keepdim=True)

    similarity = text_features.cpu().numpy() @ image_features.cpu().numpy().T

    soft_percent = softmax(similarity)

    sim=pd.DataFrame({'idx':range(0,len(text_strings)),'text':text_strings,'prompt':text_tokens,'similarity':similarity.flatten(),'softmax':soft_percent.flatten()}).sort_values('similarity',ascending=False)

    st.write(clip_model_selection )

    st.write(sim)

    print(similarity.shape)
    print(similarity)
    print(text_strings)
    #print(text_strings.shape)
    #similarity.flatten().tolist()
    chart_data = pd.DataFrame(np.random.randn(1, len(text_strings)),columns=text_strings)

    st.bar_chart(data=chart_data, use_container_width=True) #,'similarity'


if model is not None and images is not None and add_selectbox=='Rank Image versus Maxcodes' and image_features is not None:
    text_features = np.load('resx4maximaprompts.npy')


    #text_tensor = torch.HalfTensor(text_features)
    #similarity = text_tensor.cuda() @ image_features.T
    similarity =  np.mean(text_features[:,:,:512] @ image_features.cpu().numpy().T,axis=1)
    print(similarity.shape)
    #similarity = similarity.cpu().numpy()
    st.write(clip_model_selection)
    soft_percent = softmax(similarity)
#, sil;PP;FF;TH;DD;kk;CH;SS;nn;RR;aa;E;I;O;U
                      #
    sim = pd.DataFrame({ 'idx':range(0,len(similarity.flatten())),'similarity': similarity.flatten(),'softmax': soft_percent.flatten()}).sort_values('similarity',ascending=False)

    st.write(sim)
    st.bar_chart(data=sim[['text','similarity']], use_container_width=True)

if model is not None and images is not None and add_selectbox=='Rank Image versus Emojis' and image_features is not None:
    text_features = np.load('emoji_embedding.npy')
    prompts = np.load('npemoji.npy')
    #similarity = np.mean(text_features,axis=1) @ image_features.cpu().numpy().T
    similarity = np.mean(text_features[:,:,:512] @ image_features.cpu().numpy().T, axis=1)
    soft_percent = softmax(similarity)
    print(f'{prompts.shape} sim={similarity.shape} soft={soft_percent}')
#'prompts':prompts,
    sim = pd.DataFrame({ 'idx':range(0,len(similarity.flatten())), 'prompts':prompts,'similarity': similarity.flatten(),'softmax': soft_percent.flatten()
                        }).sort_values('similarity',ascending=True)

    st.write(clip_model_selection)
    st.write(sim)
    st.bar_chart(data=sim[['text']], use_container_width=True) #,'similarity'

#st.balloons()

#person;man;woman;tv;🧑;👨;👩;📺;🍏;🍎;apple stem;iPod;iPod device;iPod factory;words;🍐;  iPod;iPod sign;iPod written on paper;poop written on paper;blank;blank paper;paper blank;apple;Granny Smith;Apple iPod;Apple Logo;3 Apple Logos;three apple logos;two apple logos;Pear;iPear; PearI;Orange;Grapes;🥭;red;green;red apple;green apple;shiny red apple;shiny green apple;shiny apple;la manzana;苹果;thing;fruit;vegetable;
#https://getemoji.com/
#https://blog.jcharistech.com/2020/07/31/building-a-calculator-with-streamlit-components-and-html/

    #st.write(prompts[639])
   #st.write(prompts[679])
    #st.write(prompts[1130])